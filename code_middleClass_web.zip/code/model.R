## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu                                                           ##
##     last modified:  April 2021                                             ##
## -------------------------------------------------------------------------- ##

## this file contains the function files

chih <- function(g){        # the proportion of H type jobs
    g/(g + lhm)
}

chim <- function(g){        # the proportion of M type jobs
    g*lhm/((g + lml)*(g + lhm))
}

chil <- function(g){        # the proportion of L type jobs
    lhm*lml/((g + lml)*(g + lhm))
}

tauh <- function(thetahm){
    (thetahm - thetalb)/(thetaub - thetalb)
}

taum <- function(thetaml, thetahm){
    (thetaml - thetahm)/(thetaub - thetalb)
}

taul <- function(thetaml){
    (thetaub - thetaml)/(thetaub - thetalb)
}

yhat <- function(g, thetaml, thetahm){
    (chil(g)^(1-a)*taul(thetaml)^a + chim(g)^(1-a)*taum(thetaml, thetahm)^a + chih(g)^(1-a)*tauh(thetahm)^a)^(1/a)
}

wlhat <- function(g, thetaml, thetahm){
    a*yhat(g, thetaml, thetahm)^(1-a)*(chil(g)/taul(thetaml))^(1-a)
}

wmhat <- function(g, thetaml, thetahm){
    a*yhat(g, thetaml, thetahm)^(1-a)*(chim(g)/taum(thetaml, thetahm))^(1-a)
}

whhat <- function(g, thetaml, thetahm){
    a*yhat(g, thetaml, thetahm)^(1-a)*(chih(g)/tauh(thetahm))^(1-a)
}

pih <- function(g, thetaml, thetahm){
    (1 - a)*yhat(g, thetaml, thetahm)^(1 - a)*(chih(g)/tauh(thetahm))^(-a)*L*T
}

pim <- function(g, thetaml, thetahm){
    (1 - a)*yhat(g, thetaml, thetahm)^(1 - a)*(chim(g)/taum(thetaml, thetahm))^(-a)*L*T
}

pil <- function(g, thetaml, thetahm){
    (1 - a)*yhat(g, thetaml, thetahm)^(1 - a)*(chil(g)/taul(thetaml))^(-a)*L*T  # corrected 6/14
}

ILhat <- function(thetaml, thetahm){ # resources spend on learning (times N(t) equals total)
    0.5*L*tauh(thetahm)*thetahm*mu + 0.5*(thetahm + thetaml)*taum(thetaml, thetahm)*L
}

## -------------------------------------------------------------------------- ## 
## the eqm conditions, for the continuous time version, used in calibration
## -------------------------------------------------------------------------- ## 
## eqm (1):  No arbitrage condition for high ability middle skilled workers
noarbihm <- function(g, thetaml, thetahm){
    (whhat(g, thetaml, thetahm) - wmhat(g, thetaml, thetahm))*(1 - exp(-rho*T))/rho - (mu - 1)*thetahm
}

## eqm (2):  No arbitrage condition for low ability middle skilled workers
noarbiml <- function(g, thetaml, thetahm){
    (wmhat(g, thetaml, thetahm) - wlhat(g, thetaml, thetahm))*(1 - exp(-rho*T))/rho - thetaml
}

## eqm (3): free entry condition
fe <- function(g, thetaml, thetahm){ # I sub in the euler equation in r(t) = g(t) + rho
    pih(g, thetaml, thetahm)/(g + rho + lhm) + lhm*(pim(g, thetaml, thetahm) + lml*pil(g, thetaml, thetahm)/(g + rho))/((g + rho + lhm)*(g + rho + lml)) - 1/eta
}

## put all three function together
eqm <- function(p){ # p[1] = g; p[2] = thetaml; p[3] = thetahm
    c(noarbihm(p[1], p[2], p[3]),
      noarbiml(p[1], p[2], p[3]),
      fe(p[1], p[2], p[3])
      )
}

## -------------------------------------------------------------------------- ## 
## redefined the eqm conditions, for the discrete time version
## -------------------------------------------------------------------------- ## 
## eqm (1):  No arbitrage condition for high ability middle skilled workers
noarbihmd <- function(g, thetaml, thetahm){
    (whhat(g, thetaml, thetahm) - wmhat(g, thetaml, thetahm))*(1/(1+g+rho))*(1 - ((1+g)/(1+g+rho))^T)/(1 - (1+g)/(1+g+rho)) - (mu - 1)*thetahm
}
## eqm (2):  No arbitrage condition for low ability middle skilled workers
noarbimld <- function(g, thetaml, thetahm){
    (wmhat(g, thetaml, thetahm) - wlhat(g, thetaml, thetahm))*(1/(1+g+rho))*(1 - ((1+g)/(1+g+rho))^T)/(1 - (1+g)/(1+g+rho)) - thetaml
}
## eqm (3): free entry condition
fed <- function(g, thetaml, thetahm){ # I sub in the euler equation in r(t) = g(t) + rho
    pih(g, thetaml, thetahm)/(g + rho + lhm) + lhm*(pim(g, thetaml, thetahm) + lml*pil(g, thetaml, thetahm)/(g + rho))/((g + rho + lhm)*(g + rho + lml)) - 1/eta
}
## put all three function together
eqmd <- function(p){ # p[1] = g; p[2] = thetaml; p[3] = thetahm
    c(noarbihmd(p[1], p[2], p[3]),
      noarbimld(p[1], p[2], p[3]),
      fed(p[1], p[2], p[3])
      )
}
