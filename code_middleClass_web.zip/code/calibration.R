## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu                                                           ##
##     last modified:  April 2021                                             ##
## -------------------------------------------------------------------------- ##

## this file contains the calibration and the decomposition exercise

getwd()
library(rootSolve) # solving nonlinear equations

## load the function definitions
source("./model.R")

## externally determined parameters
a       <- 0.8  # the mark-up level, Christopoulou and Vermeulen (2008)
T       <- 45   # active years of workers 20 - 64
L       <- 4.6  # EU labour force 207 mil (averaged from 2000 to 2014), source
                # "worldbank development indicator database".
rho     <- 0.04 # subjective discount factor (annual), business cycle literature
thetalb <- 0    # lowest training cost level, normalization

## ------------------
## calibration 2000
## ------------------

## - targets in 2000
##   - wH/wM = 1.79
##   - wM/wL = 1.24
##   - tau_H = 38%
##   - tau_M = 33% (tau_L = 29%)
##   - gt = 1.9%   HP filter trend growth rate in 2000

## internal calibrated parameters
eta     <- 0.00255 # inverse of the cost of product innovation
lhm     <- 0.00117 # pc rate from start-up to routine
lml     <- 0.00578 # pc rate from routine to manual
mu      <- 8.5     # how costly is the high-skilled training relative to the
                   # middle-skilled training
thetaub <- 2.9     # the highest level of training cost

## solve for the equilibrium
p0   <- c(0.02, 0.6*thetaub, 0.3*thetaub) # p0 is the initial guess vector: p[1] = g; p[2] = thetaml; p[3] = thetahm
eqm0 <- multiroot(f = eqm, start = p0)    # eqm is the continuous version equilibrium conditions
eqm0

## record the results
g0       <- eqm0$root[1]
thetaml0 <- eqm0$root[2]
thetahm0 <- eqm0$root[3]
wlhat0   <- wlhat(g0, thetaml0, thetahm0)
wmhat0   <- wmhat(g0, thetaml0, thetahm0)
whhat0   <- whhat(g0, thetaml0, thetahm0)
yhat0    <- yhat(g0, thetaml0, thetahm0)
taul0    <- taul(thetaml0)
taum0    <- taum(thetaml0, thetahm0)
tauh0    <- tauh(thetahm0)
ilhat0   <- ILhat(thetaml0, thetahm0)

## put the results in a table and display the table
results <- matrix(NA, nrow = 18, ncol = 1) # empty table
df2000  <- as.data.frame(results) # this is the table that store the results
row.names(df2000) <- c("a", "T", "L", "rho", "thetalb", "eta", "lhm", "lml",
                       "mu", "thetaub", "g*", "whom*", "wmol*", "tauh*",
                       "taum*", "taul*", "yhat*", "ilhat")
colnames(df2000)[1] = c("bl2000") # bl2000 -> baseline case 2000
df2000$bl2000 <- c(a, T, L, rho, thetalb, eta, lhm, lml, mu, thetaub, g0,
                   whhat0/wmhat0, wmhat0/wlhat0, tauh0, taum0, taul0, yhat0,
                   ilhat0)
df2000

## double checking the results
TT = 6000 # we need the time period to be long enough
rss <- g0 + rho
lfwhhat0 <- whhat0*(1 - exp(-rho*TT))/rho # life time income of H-hat
lfwmhat0 <- wmhat0*(1 - exp(-rho*TT))/rho # life time income of M-hat
lfwlhat0 <- wlhat0*(1 - exp(-rho*TT))/rho # life time income of L-hat
lfwhhat0
lfwmhat0
lfwlhat0

ltwhhat0d <- 0 # initialization
ltwmhat0d <- 0
ltwlhat0d <- 0
for (z in 1:TT){
    ltwhhat0d <- ltwhhat0d + whhat0*(1 + g0)^(z - 1)/(1 + rss)^(z) 
    ltwmhat0d <- ltwmhat0d + wmhat0*(1 + g0)^(z - 1)/(1 + rss)^(z) 
    ltwlhat0d <- ltwlhat0d + wlhat0*(1 + g0)^(z - 1)/(1 + rss)^(z) 
}
ltwhhat0d # matches the above result when TT is big enough, e.g. TT = 6000
ltwmhat0d
ltwlhat0d

P <- read.table(file = "./outputs/P2000.txt") # load the transition matrix
WH <- 0 # initialization
WM <- 0
WL <- 0
pihss <- pih(g0, thetaml0, thetahm0)
pimss <- pim(g0, thetaml0, thetahm0)
pilss <- pil(g0, thetaml0, thetahm0)
rss <- g0 + rho
ll <- nrow(P)
for (z in 1:ll){
    WH <- WH + P[z,1]*pihss/(1 + rss)^(z)
    WM <- WM + P[z,2]*pimss/(1 + rss)^(z)
    WL <- WL + P[z,3]*pilss/(1 + rss)^(z)
}
WH + WM + WL
1/eta # should match the above value
## calibration for 2000 ---------------------------------------------------- ##

## ------------------
## calibration 2014
## ------------------

## - targets in 2014
##   - wH/wM = 1.82
##   - wM/wL = 1.14
##   - tau_H = 47%
##   - tau_M = 23.5% (tau_L = 29.5%)
##   - g = 0.8%   HP filter trend growth rate in 2014

## internal
eta     <- 0.00200 # inverse of the cost of product innovation
lhm     <- 0.00034 # pc rate from start-up to routine
lml     <- 0.00560 # pc rate from routine to manual
mu      <- 10.67   # how costly is the high-skilled training relative to the
                   # middle-skilled training
thetaub <- 1.83    # the highest training cost level

## calculate the equilibrium 
p0 <- c(0.008, 0.7*thetaub, 0.4*thetaub ) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqm1 <- multiroot(f = eqm, start = p0)
eqm1

## record the results
g1       <- eqm1$root[1]
thetaml1 <- eqm1$root[2]
thetahm1 <- eqm1$root[3]
wlhat1   <- wlhat(g1, thetaml1, thetahm1)
wmhat1   <- wmhat(g1, thetaml1, thetahm1)
whhat1   <- whhat(g1, thetaml1, thetahm1)
yhat1    <- yhat(g1, thetaml1, thetahm1)
taul1    <- taul(thetaml1)
taum1    <- taum(thetaml1, thetahm1)
tauh1    <- tauh(thetahm1)
ilhat1   <- ILhat(thetaml1, thetahm1)

## put the results in a table
results = matrix(NA, nrow = 18, ncol = 1) # empty table
df2014 = as.data.frame(results) # this is the table that store the results
row.names(df2014) <- c("a", "T", "L", "rho", "thetalb", "eta", "lhm", "lml",
                       "mu", "thetaub", "g*", "whom*", "wmol*", "tauh*",
                       "taum*", "taul*", "yhat*", "ilhat")
colnames(df2014)[1] = c("bl2014")
df2014$bl2014 <- c(a, T, L, rho, thetalb, eta, lhm, lml, mu, thetaub, g1,
                   whhat1/wmhat1, wmhat1/wlhat1, tauh1, taum1, taul1, yhat1,
                   ilhat1)
df2014

## double checking the results
## we need a new transition matrix here
P2014 <- read.table(file = "./outputs/P2014.txt")
WH1 <- 0 # initialization
WM1 <- 0
WL1 <- 0
pihss1 <- pih(g1, thetaml1, thetahm1)
pimss1 <- pim(g1, thetaml1, thetahm1)
pilss1 <- pil(g1, thetaml1, thetahm1)
rss1 <- g1 + rho
ll <- nrow(P)
for (z in 1:ll){
    WH1 <- WH1 + P2014[z,1]*pihss1/(1 + rss1)^(z)
    WM1 <- WM1 + P2014[z,2]*pimss1/(1 + rss1)^(z)
    WL1 <- WL1 + P2014[z,3]*pilss1/(1 + rss1)^(z)
}
WH1 + WM1 + WL1
1/eta # should match with the above value
## calibration for 2014 ----------------------------------------------------- ##


## -------------------------------------------------------------------------- ##
## decomposition exercise 1: a decrease in eta
## -------------------------------------------------------------------------- ##
eta     <- 0.00227 # inverse of the cost of product innovation
lhm     <- 0.00117 # pc rate from start-up to routine
lml     <- 0.00578 # pc rate from routine to manual
mu      <- 8.5     # how costly is the high-skilled training relative to the
                   # middle-skilled training
thetaub <- 2.9     # the highest training cost level

## solve for the equilibrium
p0   <- c(0.02, 0.6*thetaub, 0.3*thetaub) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqmx <- multiroot(f = eqm, start = p0)
eqmx
## record the results
gx       <- eqmx$root[1]
thetamlx <- eqmx$root[2]
thetahmx <- eqmx$root[3]
wlhatx   <- wlhat(gx, thetamlx, thetahmx)
wmhatx   <- wmhat(gx, thetamlx, thetahmx)
whhatx   <- whhat(gx, thetamlx, thetahmx)
yhatx    <- yhat(gx, thetamlx, thetahmx)
taulx    <- taul(thetamlx)
taumx    <- taum(thetamlx, thetahmx)
tauhx    <- tauh(thetahmx)
ilhatx   <- ILhat(thetamlx, thetahmx)
## put the results in a table and display the table
results <- matrix(NA, nrow = 18, ncol = 1) # empty table
dfx  <- as.data.frame(results) # this is the table that store the results
row.names(dfx) <- c("a", "T", "L", "rho", "thetalb", "eta", "lhm", "lml", "mu",
                    "thetaub", "g*", "whom*", "wmol*", "tauh*", "taum*",
                    "taul*", "yhat*", "ilhat")
colnames(dfx)[1] = c("blx") # blx -> baseline case x
dfx$blx <- c(a, T, L, rho, thetalb, eta, lhm, lml, mu, thetaub, gx,
                   whhatx/wmhatx, wmhatx/wlhatx, tauhx, taumx, taulx, yhatx,
                   ilhatx)
dfx
## decomposition exercise 1: a drcrease in eta ------------------------------ ##


## -------------------------------------------------------------------------- ##
## decomposition exercise 2: a decrease in lhm
## -------------------------------------------------------------------------- ##
eta     <- 0.00255 # inverse of the cost of product innovation
lhm     <- 0.00034 # pc rate from start-up to routine
lml     <- 0.00578 # pc rate from routine to manual
mu      <- 8.5     # how costly is the high-skilled training relative to the
                   # middle-skilled training
thetaub <- 2.9     # the highest training cost level

## solve for the equilibrium
p0   <- c(0.02, 0.6*thetaub, 0.3*thetaub) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqmx <- multiroot(f = eqm, start = p0)
eqmx
## record the results
gx       <- eqmx$root[1]
thetamlx <- eqmx$root[2]
thetahmx <- eqmx$root[3]
wlhatx   <- wlhat(gx, thetamlx, thetahmx)
wmhatx   <- wmhat(gx, thetamlx, thetahmx)
whhatx   <- whhat(gx, thetamlx, thetahmx)
yhatx    <- yhat(gx, thetamlx, thetahmx)
taulx    <- taul(thetamlx)
taumx    <- taum(thetamlx, thetahmx)
tauhx    <- tauh(thetahmx)
ilhatx   <- ILhat(thetamlx, thetahmx)
## put the results in a table and display the table
results <- matrix(NA, nrow = 18, ncol = 1) # empty table
dfx  <- as.data.frame(results) # this is the table that store the results
row.names(dfx) <- c("a", "T", "L", "rho", "thetalb", "eta", "lhm", "lml", "mu",
                    "thetaub", "g*", "whom*", "wmol*", "tauh*", "taum*",
                    "taul*", "yhat*", "ilhat")
colnames(dfx)[1] = c("blx") # blx -> baseline case x
dfx$blx <- c(a, T, L, rho, thetalb, eta, lhm, lml, mu, thetaub, gx,
                   whhatx/wmhatx, wmhatx/wlhatx, tauhx, taumx, taulx, yhatx,
                   ilhatx)
dfx
## decomposition exercise 2: a drcrease in lhm ------------------------------ ##


## -------------------------------------------------------------------------- ##
## decomposition exercise 3: a decrease in lml
## -------------------------------------------------------------------------- ##
eta     <- 0.00255 # inverse of the cost of product innovation
lhm     <- 0.00117 # pc rate from start-up to routine
lml     <- 0.00560 # pc rate from routine to manual
mu      <- 8.5     # how costly is the high-skilled training relative to the
                   # middle-skilled training
thetaub <- 2.9     # the highest training cost level

## solve for the equilibrium
p0   <- c(0.02, 0.6*thetaub, 0.3*thetaub) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqmx <- multiroot(f = eqm, start = p0)
eqmx
## record the results
gx       <- eqmx$root[1]
thetamlx <- eqmx$root[2]
thetahmx <- eqmx$root[3]
wlhatx   <- wlhat(gx, thetamlx, thetahmx)
wmhatx   <- wmhat(gx, thetamlx, thetahmx)
whhatx   <- whhat(gx, thetamlx, thetahmx)
yhatx    <- yhat(gx, thetamlx, thetahmx)
taulx    <- taul(thetamlx)
taumx    <- taum(thetamlx, thetahmx)
tauhx    <- tauh(thetahmx)
ilhatx   <- ILhat(thetamlx, thetahmx)
## put the results in a table and display the table
results <- matrix(NA, nrow = 18, ncol = 1) # empty table
dfx  <- as.data.frame(results) # this is the table that store the results
row.names(dfx) <- c("a", "T", "L", "rho", "thetalb", "eta", "lhm", "lml", "mu",
                    "thetaub", "g*", "whom*", "wmol*", "tauh*", "taum*",
                    "taul*", "yhat*", "ilhat")
colnames(dfx)[1] = c("blx") # blx -> baseline case x
dfx$blx <- c(a, T, L, rho, thetalb, eta, lhm, lml, mu, thetaub, gx,
                   whhatx/wmhatx, wmhatx/wlhatx, tauhx, taumx, taulx, yhatx,
                   ilhatx)
dfx
## decomposition exercise 3: a decrease in lml ------------------------------ ##


## -------------------------------------------------------------------------- ##
## decomposition exercise 4: an increase in mu
## -------------------------------------------------------------------------- ##
eta     <- 0.00255 # inverse of the cost of product innovation
lhm     <- 0.00117 # pc rate from start-up to routine
lml     <- 0.00578 # pc rate from routine to manual
mu      <- 10.67   # how costly is the high-skilled training relative to the
                   # middle-skilled training
thetaub <- 2.9     # the highest training cost level

## solve for the equilibrium
p0   <- c(0.02, 0.6*thetaub, 0.3*thetaub) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqmx <- multiroot(f = eqm, start = p0)
eqmx
## record the results
gx       <- eqmx$root[1]
thetamlx <- eqmx$root[2]
thetahmx <- eqmx$root[3]
wlhatx   <- wlhat(gx, thetamlx, thetahmx)
wmhatx   <- wmhat(gx, thetamlx, thetahmx)
whhatx   <- whhat(gx, thetamlx, thetahmx)
yhatx    <- yhat(gx, thetamlx, thetahmx)
taulx    <- taul(thetamlx)
taumx    <- taum(thetamlx, thetahmx)
tauhx    <- tauh(thetahmx)
ilhatx   <- ILhat(thetamlx, thetahmx)
## put the results in a table and display the table
results <- matrix(NA, nrow = 18, ncol = 1) # empty table
dfx  <- as.data.frame(results) # this is the table that store the results
row.names(dfx) <- c("a", "T", "L", "rho", "thetalb", "eta", "lhm", "lml", "mu",
                    "thetaub", "g*", "whom*", "wmol*", "tauh*", "taum*",
                    "taul*", "yhat*", "ilhat")
colnames(dfx)[1] = c("blx") # blx -> baseline case x
dfx$blx <- c(a, T, L, rho, thetalb, eta, lhm, lml, mu, thetaub, gx,
                   whhatx/wmhatx, wmhatx/wlhatx, tauhx, taumx, taulx, yhatx,
                   ilhatx)
dfx
## decomposition exercise 4: an increase in mu ------------------------------ ##


## -------------------------------------------------------------------------- ##
## decomposition exercise 5: a decrease in thetaub
## -------------------------------------------------------------------------- ##
eta     <- 0.00255 # inverse of the cost of product innovation
lhm     <- 0.00117 # pc rate from start-up to routine
lml     <- 0.00578 # pc rate from routine to manual
mu      <- 8.50    # how costly is the high-skilled training relative to the
                   # middle-skilled training
thetaub <- 2.1    # the highest training cost level

## solve for the equilibrium
p0   <- c(0.02, 0.6*thetaub, 0.3*thetaub) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqmx <- multiroot(f = eqm, start = p0)
eqmx
## record the results
gx       <- eqmx$root[1]
thetamlx <- eqmx$root[2]
thetahmx <- eqmx$root[3]
wlhatx   <- wlhat(gx, thetamlx, thetahmx)
wmhatx   <- wmhat(gx, thetamlx, thetahmx)
whhatx   <- whhat(gx, thetamlx, thetahmx)
yhatx    <- yhat(gx, thetamlx, thetahmx)
taulx    <- taul(thetamlx)
taumx    <- taum(thetamlx, thetahmx)
tauhx    <- tauh(thetahmx)
ilhatx   <- ILhat(thetamlx, thetahmx)
## put the results in a table and display the table
results <- matrix(NA, nrow = 18, ncol = 1) # empty table
dfx  <- as.data.frame(results) # this is the table that store the results
row.names(dfx) <- c("a", "T", "L", "rho", "thetalb", "eta", "lhm", "lml", "mu",
                    "thetaub", "g*", "whom*", "wmol*", "tauh*", "taum*",
                    "taul*", "yhat*", "ilhat")
colnames(dfx)[1] = c("blx") # blx -> baseline case x
dfx$blx <- c(a, T, L, rho, thetalb, eta, lhm, lml, mu, thetaub, gx,
                   whhatx/wmhatx, wmhatx/wlhatx, tauhx, taumx, taulx, yhatx,
                   ilhatx)
dfx
## decomposition exercise 5: a decrease in thetaub -------------------------- ##









## ## results ------------------------------------------------------------------ ##
##           2000 bl       lhm -        lml -        thetaub -    mu +          eta -        bl2014
## a        0.8000000    0.8000000    0.8000000    0.8000000    0.80000000    0.8000000    0.80000000
## T       45.0000000   45.0000000   45.0000000   45.0000000   45.00000000   45.0000000   45.00000000
## L        4.6000000    4.6000000    4.6000000    4.6000000    4.60000000    4.6000000    4.60000000
## rho      0.0400000    0.0400000    0.0400000    0.0400000    0.04000000    0.0400000    0.04000000
## thetalb  0.0000000    0.0000000    0.0000000    0.0000000    0.00000000    0.0000000    0.00000000

## eta      0.0025500    0.0025500    0.0025500    0.0025500    0.00255000    0.0022700    0.00200000
## lhm      0.0011700    0.0003400    0.0011700    0.0011700    0.00117000    0.0011700    0.00034000
## lml      0.0057800    0.0057800    0.0056000    0.0057800    0.00578000    0.0057800    0.00560000
## mu       8.5000000    8.5000000    8.5000000    8.5000000   10.67000000    8.5000000   10.67000000
## thetaub  2.9000000    2.9000000    2.9000000    2.1000000    2.90000000    2.9000000    1.83000000

## g*       0.0193732    0.0201308 +  0.0194376 +  0.0337614 +  0.00768627 -  0.0054496 -  0.00845617
## whom*    1.7867687    2.1321649 +  1.7887704 +  1.8353795 +  1.63596830 -  1.4944383 -  1.82242803
## wmol*    1.2403337    1.3127538 +  1.2425015 +  1.2195498 -  1.15304102 -  1.1326622 -  1.14469536
## tauh*    0.3862473    0.4493366 +  0.3867112 +  0.5260717 +  0.27943880 -  0.3019122 -  0.47188864
## taum*    0.3271900    0.2598209 -  0.3309425 +  0.3241966 -  0.28451148 -  0.2344727 -  0.22945808
## taul*    0.2865627    0.2908424 +  0.2823462 -  0.1497317 -  0.43604972 +  0.4636152 +  0.29865328
## yhat*    0.7984669    0.7443061    0.7983931    0.8392155    0.82655161    0.8711070    0.82130097
## ilhat*  10.8580582   13.4545907   10.9162471   13.5172000    7.15779007    6.4788430   11.13361339
## ## results ------------------------------------------------------------------ ##
