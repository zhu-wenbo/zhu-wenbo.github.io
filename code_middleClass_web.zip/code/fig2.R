## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu                                                           ##
##     last modified:  April 2021                                             ##
## -------------------------------------------------------------------------- ##

## this file retrieves the relevant data for plotting Figure 2 in the paper.

getwd()

library(eurostat) # for retrieving the raw data from Eurostat
library(dplyr)    # for various data manipulation

## ---------------------------------------------------------------------------
## get the data from Eurostat between 2000 and 2016
## ---------------------------------------------------------------------------

## ## 2000/01:
## inn3prod <- get_eurostat("inn_prod", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## ## 2004:
## inn4prod <- get_eurostat("inn_cis4_prod", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## ## 2006:
## inn5prod <- get_eurostat("inn_cis5_prod", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## ## 2008:
## inn6type <- get_eurostat("inn_cis6_type", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## ## 2010:
## inn7type <- get_eurostat("inn_cis7_type", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## ## 2012:
## inn8type <- get_eurostat("inn_cis8_type", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## ## 2014:  everything else
## inn9type <- get_eurostat("inn_cis9_type", time_format = "raw", cache_dir = "./eurostat_RAWdata")
## ## total number of firms
## inn9bas <- get_eurostat("inn_cis9_bas", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## ## 2016:
## inn_cis10_type <- get_eurostat("inn_cis10_type", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## load the downloaded data
inn3prod <- readRDS(file = "./eurostat_RAWdata/inn_prod_raw_code_FF.rds")
inn4prod <- readRDS(file = "./eurostat_RAWdata/inn_cis4_prod_raw_code_FF.rds")
inn5prod <- readRDS(file = "./eurostat_RAWdata/inn_cis5_prod_raw_code_FF.rds")
inn6type <- readRDS(file = "./eurostat_RAWdata/inn_cis6_type_raw_code_FF.rds")
inn7type <- readRDS(file = "./eurostat_RAWdata/inn_cis7_type_raw_code_FF.rds")
inn8type <- readRDS(file = "./eurostat_RAWdata/inn_cis8_type_raw_code_FF.rds")
inn9type <- readRDS(file = "./eurostat_RAWdata/inn_cis9_type_raw_code_FF.rds")
inn9bas  <- readRDS(file = "./eurostat_RAWdata/inn_cis9_bas_raw_code_FF.rds")
inn_cis10_type <- readRDS(file = "./eurostat_RAWdata/inn_cis10_type_raw_code_FF.rds")



## ---------------------------------------------------------------------------
## select the data needed and re-organize them by industry
## ---------------------------------------------------------------------------
## 2000 (CIS 3)
cl00 <- as.matrix(unique(inn3prod$nace_r1))
cl00 <- sort(cl00[nchar(cl00)==1,])

inn3pcsonly <- filter(inn3prod, indic_in == "ENT_POPU", sizeclas == "TOTAL",
                      unit == "NR", nace_r1 %in% cl00, type_inn == "INPCSONLY")%>%
  select(nace_r1, geo, values)
colnames(inn3pcsonly) <- c("industry", "country", "pcsonly")

inn3pandp <- filter(inn3prod, indic_in == "ENT_POPU", sizeclas == "TOTAL",
                    unit == "NR", nace_r1 %in% cl00, type_inn == "PANDP")%>%
  select(nace_r1, geo, values)
colnames(inn3pandp) <- c("industry", "country", "pandp")

inn3totaln <- filter(inn3prod, indic_in == "ENT_POPU", sizeclas == "TOTAL",
                     unit == "NR", nace_r1 %in% cl00, type_inn == "TOTAL")%>%
  select(nace_r1, geo, values)
colnames(inn3totaln) <- c("industry", "country", "totaln")

inn00data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn3pcsonly, inn3pandp, inn3totaln))

inn00data$pcs <- inn00data$pcsonly + inn00data$pandp

write.csv(inn00data, file = "./eurostat_CLEANEDdata/inn00data.csv", row.names = F)

## 2004 (CIS 4)
cl04 <- as.matrix(unique(inn4prod$nace_r1))
cl04 <- sort(cl04[nchar(cl04)==1,])

inn4pcsonly <- filter(inn4prod, indic_in == "ENT_POPU04", sizeclas == "TOTAL",
                      unit == "NR", nace_r1 %in% cl04, type_inn == "INPCSONLY") %>%
  select(nace_r1, geo, values)
colnames(inn4pcsonly) <- c("industry", "country", "pcsonly")

inn4pandp <- filter(inn4prod, indic_in == "ENT_POPU04", sizeclas == "TOTAL",
                    unit == "NR", nace_r1 %in% cl04, type_inn == "PANDP") %>%
  select(nace_r1, geo, values)
colnames(inn4pandp) <- c("industry", "country", "pandp")

inn4totaln <- filter(inn4prod, indic_in == "ENT_POPU04", sizeclas == "TOTAL",
                     unit == "NR", nace_r1 %in% cl04, type_inn == "TOTAL")%>%
  select(nace_r1, geo, values)
colnames(inn4totaln) <- c("industry", "country", "totaln")

inn04data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn4pcsonly, inn4pandp, inn4totaln))

inn04data$pcs <- inn04data$pcsonly + inn04data$pandp

write.csv(inn04data, file = "./eurostat_CLEANEDdata/inn04data.csv", row.names = F)

## 2006 (CIS 5)
cl06 <- as.matrix(unique(inn5prod$nace_r1))
cl06 <- sort(cl06[nchar(cl06)==1,])

inn5pcsonly <- filter(inn5prod, indic_in == "ENT_POPU06", sizeclas == "TOTAL",
                      unit == "NR", nace_r1 %in% cl06, type_inn == "INPCSONLY") %>%
  select(nace_r1, geo, values)
colnames(inn5pcsonly) <- c("industry", "country", "pcsonly")

inn5pandp <- filter(inn5prod, indic_in == "ENT_POPU06", sizeclas == "TOTAL",
                    unit == "NR", nace_r1 %in% cl06, type_inn == "PANDP") %>%
  select(nace_r1, geo, values)
colnames(inn5pandp) <- c("industry", "country", "pandp")

inn5totaln <- filter(inn5prod, indic_in == "ENT_POPU06", sizeclas == "TOTAL",
                     unit == "NR", nace_r1 %in% cl06, type_inn == "TOTAL")%>%
  select(nace_r1, geo, values)
colnames(inn5totaln) <- c("industry", "country", "totaln")

inn06data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn5pcsonly, inn5pandp, inn5totaln))

inn06data$pcs <- inn06data$pcsonly + inn06data$pandp

write.csv(inn06data, file = "./eurostat_CLEANEDdata/inn06data.csv", row.names = F)

## 2008 (CIS 6)
cl08t <- as.matrix(unique(inn6type$nace_r2))
cl08t <- sort(cl08t[nchar(cl08t)==1,])

inn6pcsonly <- filter(inn6type, indic_in == "ENT_POPU08", sizeclas == "TOTAL",
                      unit == "NR", nace_r2 %in% cl08t, type_inn == "INPCSONLY") %>%
  select(nace_r2, geo, values)
colnames(inn6pcsonly) <- c("industry", "country", "pcsonly")

inn6pandp <- filter(inn6type, indic_in == "ENT_POPU08", sizeclas == "TOTAL",
                    unit == "NR", nace_r2 %in% cl08t, type_inn == "PANDP") %>%
  select(nace_r2, geo, values)
colnames(inn6pandp) <- c("industry", "country", "pandp")

inn6totaln <- filter(inn6type, indic_in == "ENT_POPU08", sizeclas == "TOTAL",
                     unit == "NR", nace_r2 %in% cl08t, type_inn == "TOTAL") %>%
  select(nace_r2, geo, values)
colnames(inn6totaln) <- c("industry", "country", "totaln")

inn08data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn6pcsonly, inn6pandp, inn6totaln))

inn08data$pcs <- inn08data$pcsonly + inn08data$pandp

write.csv(inn08data, file = "./eurostat_CLEANEDdata/inn08data.csv", row.names = F)

## 2010 (CIS 7)
cl10t <- as.matrix(unique(inn7type$nace_r2))
cl10t <- sort(cl10t[nchar(cl10t)==1,])

inn7pcsonly <- filter(inn7type, indic_in == "ENT_POPU10", sizeclas == "TOTAL",
                      unit == "NR", nace_r2 %in% cl10t, type_inn == "INPCSONLY") %>%
  select(nace_r2, geo, values)
colnames(inn7pcsonly) <- c("industry", "country", "pcsonly")

inn7pandp <- filter(inn7type, indic_in == "ENT_POPU10", sizeclas == "TOTAL",
                    unit == "NR", nace_r2 %in% cl10t, type_inn == "PANDP") %>%
  select(nace_r2, geo, values)
colnames(inn7pandp) <- c("industry", "country", "pandp")

inn7totaln <- filter(inn7type, indic_in == "ENT_POPU10", sizeclas == "TOTAL",
                     unit == "NR", nace_r2 %in% cl10t, type_inn == "TOTAL") %>%
  select(nace_r2, geo, values)
colnames(inn7totaln) <- c("industry", "country", "totaln")

inn10data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn7pcsonly, inn7pandp, inn7totaln))

inn10data$pcs <- inn10data$pcsonly + inn10data$pandp

write.csv(inn10data, file = "./eurostat_CLEANEDdata/inn10data.csv", row.names = F)

## 2012 (CIS 8)
cl12t <- as.matrix(unique(inn8type$nace_r2))
cl12t <- sort(cl12t[nchar(cl12t)==1,])

inn8pcsonly <- filter(inn8type, indic_in == "ENT_POPU12", sizeclas == "TOTAL",
                      unit == "NR", nace_r2 %in% cl12t, type_inn == "INPCSONLY") %>%
  select(nace_r2, geo, values)
colnames(inn8pcsonly) <- c("industry", "country", "pcsonly")

inn8pandp <- filter(inn8type, indic_in == "ENT_POPU12", sizeclas == "TOTAL",
                    unit == "NR", nace_r2 %in% cl12t, type_inn == "PANDP") %>%
  select(nace_r2, geo, values)
colnames(inn8pandp) <- c("industry", "country", "pandp")

## Apr 27th, 2021 --------------------------------------------------------------
## Eurostat, for some reason, has removed type_inn == "TOTAL" for this dataset
## inn8totaln <- filter(inn8type, indic_in == "ENT_POPU12", sizeclas == "TOTAL",
##                      unit == "NR", nace_r2 %in% cl12t, type_inn == "TOTAL") %>%
##   select(nace_r2, geo, values)
## colnames(inn8totaln) <- c("industry", "country", "totaln")

inn8inn <- filter(inn8type, indic_in == "ENT_POPU12", sizeclas == "TOTAL",
                    unit == "NR", nace_r2 %in% cl12t, type_inn == "INNO") %>%
  select(nace_r2, geo, values)
colnames(inn8inn) <- c("industry", "country", "INNO")

inn8ninn <- filter(inn8type, indic_in == "ENT_POPU12", sizeclas == "TOTAL",
                    unit == "NR", nace_r2 %in% cl12t, type_inn == "NON_INNO") %>%
  select(nace_r2, geo, values)
colnames(inn8ninn) <- c("industry", "country", "NON_INNO")

inn12data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn8pcsonly, inn8pandp, inn8inn, inn8ninn))

inn12data$pcs <- inn12data$pcsonly + inn12data$pandp
inn12data$totaln <- inn12data$INNO + inn12data$NON_INNO

write.csv(inn12data, file = "./eurostat_CLEANEDdata/inn12data.csv", row.names = F)

## 2014 (CIS 9)
cl14t <- as.matrix(unique(inn9type$nace_r2))
cl14t <- sort(cl14t[nchar(cl14t)==1,])

inn9pcsonly <- filter(inn9type, indic_in == "ENT_POPU14", sizeclas == "TOTAL",
                      unit == "NR", nace_r2 %in% cl14t, type_inn == "INPCSONLY") %>%
  select(nace_r2, geo, values)
colnames(inn9pcsonly) <- c("industry", "country", "pcsonly")

inn9pandp <- filter(inn9type, indic_in == "ENT_POPU14", sizeclas == "TOTAL",
                    unit == "NR", nace_r2 %in% cl14t, type_inn == "PANDP") %>%
  select(nace_r2, geo, values)
colnames(inn9pandp) <- c("industry", "country", "pandp")

cl14b <- as.matrix(unique(inn9bas$nace_r2))
cl14b <- sort(cl14b[nchar(cl14b)==1,])
inn9totaln <- filter(inn9bas, sizeclas == "TOTAL", nace_r2 %in% cl14b, type_inn == "TOTAL",
                     indic_in == "ENT_POPU14", unit == "NR") %>%
  select(nace_r2, geo, values)
colnames(inn9totaln) <- c("industry", "country", "totaln")

inn14data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn9pcsonly, inn9pandp, inn9totaln))

inn14data$pcs <- inn14data$pcsonly + inn14data$pandp

write.csv(inn14data, file = "./eurostat_CLEANEDdata/inn14data.csv", row.names = F)

## 2016 (CIS 10)
il16 <- as.matrix(unique(inn_cis10_type$nace_r2))
il16 <- sort(il16[nchar(il16)==1,])

inn16pcs <- filter(inn_cis10_type, sizeclas == "TOTAL", nace_r2 %in% il16,
                      enterpr == "PCS", unit == "NR")%>%
    select(nace_r2, geo, values)
colnames(inn16pcs) <- c("industry", "country", "pcs")

inn16inn <- filter(inn_cis10_type, sizeclas == "TOTAL", nace_r2 %in% il16,
                   enterpr == "INN", unit == "NR")%>%
    select(nace_r2, geo, values)
colnames(inn16inn) <- c("industry", "country", "INN")

inn16ninn <- filter(inn_cis10_type, sizeclas == "TOTAL", nace_r2 %in% il16,
                   enterpr == "NINN", unit == "NR")%>%
    select(nace_r2, geo, values)
colnames(inn16ninn) <- c("industry", "country", "NINN")

inn16data <- Reduce(function(x, y) merge(x, y, by = c("industry", "country"), all=TRUE),
                    list(inn16pcs, inn16inn, inn16ninn))

inn16data$totaln <- inn16data$INN + inn16data$NINN

write.csv(inn16data, file = "./eurostat_CLEANEDdata/inn16data.csv", row.names = F)

## ---------------------------------------------------------------------------
## export the data to plot with 'Numbers.app'
## ---------------------------------------------------------------------------

getwd()
library(dplyr)

## read in the cleaned data sets
inn3data  <- read.csv(file = "./eurostat_CLEANEDdata/inn00data.csv") # 2000
inn4data  <- read.csv(file = "./eurostat_CLEANEDdata/inn04data.csv") # 2004
inn5data  <- read.csv(file = "./eurostat_CLEANEDdata/inn06data.csv") # 2006
inn6data  <- read.csv(file = "./eurostat_CLEANEDdata/inn08data.csv") # 2008 starting nace_r2
inn7data  <- read.csv(file = "./eurostat_CLEANEDdata/inn10data.csv") # 2010
inn8data  <- read.csv(file = "./eurostat_CLEANEDdata/inn12data.csv") # 2012
inn9data  <- read.csv(file = "./eurostat_CLEANEDdata/inn14data.csv") # 2014
inn10data <- read.csv(file = "./eurostat_CLEANEDdata/inn16data.csv") # 2016


## > unique(inn3data$country)
##  [1] "AT" "BE" "BG" "CY" "CZ" "DE" "DK" "EE" "EL" "ES" "FI" "FR" "IS" "IT" "LT" "LV" "MT" "NL" "NO" "PL" "PT" "RO" "SE"
## [24] "SI" "SK" "UK" "HU" "IE" "LU"
## > unique(inn4data$country)
##  [1] "AT"        "BE"        "BG"        "CY"        "CZ"        "DE"        "DK"        "EE"        "EL"
## [10] "ES"        "FI"        "FR"        "HU"        "IE"        "IS"        "IT"        "LT"        "LV"
## [19] "MT"        "NL"        "NO"        "PL"        "PT"        "RO"        "SE"        "SI"        "SK"
## [28] "UK"        "EU27_2007" "LU"
## > unique(inn5data$country)
##  [1] "AT"        "BE"        "BG"        "CY"        "CZ"        "DE"        "DK"        "EE"        "EL"
## [10] "ES"        "FI"        "HR"        "HU"        "IE"        "IT"        "LT"        "LV"        "MT"
## [19] "NL"        "NO"        "PL"        "PT"        "RO"        "SE"        "SI"        "SK"        "TR"
## [28] "UK"        "EU27_2007" "FR"        "LU"
## > unique(inn6data$country)
##  [1] "CY"        "DK"        "ES"        "IS"        "LT"        "LU"        "MT"        "NL"        "NO"
## [10] "PT"        "SI"        "SK"        "AT"        "BE"        "BG"        "CZ"        "DE"        "EE"
## [19] "EU27_2007" "FI"        "FR"        "HR"        "HU"        "IE"        "IT"        "LV"        "PL"
## [28] "RO"        "SE"        "UK"
## > unique(inn7data$country)
##  [1] "CY"        "DK"        "ES"        "IS"        "LT"        "MT"        "NL"        "NO"        "RS"
## [10] "AT"        "BE"        "BG"        "CZ"        "DE"        "EE"        "EU15"      "EU27_2007" "FI"
## [19] "FR"        "HR"        "HU"        "IE"        "IT"        "LU"        "LV"        "PL"        "PT"
## [28] "RO"        "SE"        "SI"        "SK"        "TR"        "UK"
## > unique(inn8data$country)
##  [1] "BE"   "CY"   "DK"   "ES"   "MT"   "NO"   "RS"   "SE"   "AT"   "BG"   "CZ"   "DE"   "EE"   "EL"   "EU15" "EU28"
## [17] "FI"   "FR"   "HR"   "HU"   "IE"   "IT"   "LT"   "LU"   "LV"   "NL"   "PL"   "PT"   "RO"   "SI"   "SK"   "TR"
## [33] "UK"
## > unique(inn9data$country)
##  [1] "CY"   "DK"   "ES"   "MT"   "NL"   "NO"   "RS"   "SE"   "AT"   "BE"   "BG"   "CZ"   "DE"   "EE"   "EL"   "EU15"
## [17] "EU28" "FI"   "FR"   "HR"   "HU"   "IE"   "IS"   "IT"   "LT"   "LU"   "LV"   "MK"   "PL"   "PT"   "RO"   "SI"
## [33] "SK"   "TR"   "UK"   "CH"
## > unique(inn10data$country)
##  [1] "BE"        "DK"        "ES"        "LT"        "ME"        "MT"        "NL"        "NO"        "PT"
## [10] "RO"        "RS"        "SI"        "AT"        "BG"        "CY"        "CZ"        "DE"        "EE"
## [19] "EL"        "EU15"      "EU27_2020" "EU28"      "FI"        "FR"        "HR"        "HU"        "IE"
## [28] "IS"        "IT"        "LU"        "LV"        "MK"        "PL"        "SE"        "SK"        "TR"
## [37] "UK"        "CH"

## remove rows of aggregated values: "EU27_2007", "EU15", "EU28", and "EU27_2020"
inn4data <- inn4data[inn4data$country != "EU27_2007", ]

inn5data <- inn5data[inn5data$country != "EU27_2007", ]

inn6data <- inn6data[inn6data$country != "EU27_2007", ]

inn7data <- inn7data[inn7data$country != "EU27_2007", ]
inn7data <- inn7data[inn7data$country != "EU15", ]

inn8data <- inn8data[inn8data$country != "EU15", ]
inn8data <- inn8data[inn8data$country != "EU28", ]

inn9data <- inn9data[inn9data$country != "EU15", ]
inn9data <- inn9data[inn9data$country != "EU28", ]

inn10data <- inn10data[inn10data$country != "EU15", ]
inn10data <- inn10data[inn10data$country != "EU28", ]
inn10data <- inn10data[inn10data$country != "EU27_2020", ]


## find industry sum (over all the countries) of process innovations and total number of firms
inlist <- list(inn3data, inn4data, inn5data, inn6data, inn7data, inn8data, inn9data, inn10data)
acDataList <- lapply(inlist, function(x) {
  select(x, industry, country, totaln, pcs) %>%
    group_by(industry) %>% summarize(totalnC = sum(totaln, na.rm = T),
                                     pcsC = sum(pcs, na.rm = T))
}
)

inn3temp <- acDataList[[1]]
inn4temp <- acDataList[[2]]
inn5temp <- acDataList[[3]]
## recode industry after 2008
## separate out data sets after 2008
names(acDataList) <- c("inn3data", "inn4data", "inn5data", "inn6data",
                       "inn7data", "inn8data", "inn9data", "inn10data")
acDataList[which(names(acDataList) %in% c("inn3data", "inn4data", "inn5data"))] <- NULL
## recode
library(car)
for (i in 1:length(acDataList)){
  acDataList[[i]]$industry <- recode(acDataList[[i]]$industry,
                                     "'B' = 'C'; 'C' = 'D'; 'D' = 'E';
                                      'I' = 'H'; 'H' = 'I'; 'J' = 'I';
                                      'K' = 'J'; 'L' = 'K'; 'M' = 'K'; 'N' = 'K';
                                      'O' = 'L'; 'P' = 'M'; 'Q' = 'N';
                                      'R' = 'O'; 'S' = 'O'")
}
## add up after recode
recodeIndustryList <- lapply(acDataList, function (x){
  x %>% group_by(industry) %>% summarize(totalnC = sum(totalnC, na.rm = T),
                                         pcsC = sum(pcsC, na.rm = T))
}
)

inn6temp  <- recodeIndustryList[[1]]
inn7temp  <- recodeIndustryList[[2]]
inn8temp  <- recodeIndustryList[[3]]
inn9temp  <- recodeIndustryList[[4]]
inn10temp <- recodeIndustryList[[5]]

## add the time column and then merge to one "long" data file for plotting
inn3temp$year  <- 2000
inn4temp$year  <- 2004
inn5temp$year  <- 2006
inn6temp$year  <- 2008
inn7temp$year  <- 2010
inn8temp$year  <- 2012
inn9temp$year  <- 2014
inn10temp$year <- 2016
plotTemp <- rbind(inn3temp, inn4temp, inn5temp, inn6temp, inn7temp, inn8temp, inn9temp, inn10temp)
plotTemp <- as.data.frame(plotTemp)

## normalize process innovations with the total number of innovations
library(reshape2)
rtpcs <- select(plotTemp, industry, year)
rtpcs$rtpcs <- plotTemp$pcsC/plotTemp$totalnC # get the rate of process innovation
rtpcsw <- dcast(rtpcs, industry ~ year, value.var = "rtpcs")

write.csv(rtpcsw, file = "./tables/rtpcsw.csv", row.names = F)
