## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu                                                           ##
##     last modified:  April 2021                                             ##
## -------------------------------------------------------------------------- ##

## this file calculates the probability for a firm being in each state,
## "start-up", "routine", and "manual" since entry (i.e., the transition matrix)

start_time <- Sys.time()

## for 2000 lhm and lmls ----------------------------------------
lhm <- 0.00117 # 2000 level
lml <- 0.00578 # 2000 level

n <- 6000 # a large number of periods (years)
P <- data.frame(
    ph = rep(NA, n), # prob in "start-up"
    pm = rep(NA, n), # prob in "routine"
    pl = rep(NA, n)  # prob in "manual"
)

P$ph[1] = 1
P$pm[1] = 0
P$pl[1] = 0
P$ph[2] = 1 - lhm
P$pm[2] = lhm
P$pl[2] = 0
for (i in 3:n){
    P$ph[i] = (1 - lhm)^(i-1)
    temp = 0 # initialization
    for (v in 1:(i-1)){
        temp = temp + (1 - lhm)^(v - 1)*lhm*(1 - lml)^(i - v - 1)
    }
    P$pm[i] = temp
    P$pl[i] = 1 - P$ph[i] - P$pm[i]

}

## export
write.table(P, file = "./outputs/P2000.txt")


## for 2014 lhm and lmls ----------------------------------------
lhm1 <- 0.00034 # 2014 level
lml1 <- 0.00560 # 2014 level

n <- 6000 # a large number of periods (years)
P2014 <- data.frame(
    ph = rep(NA, n), # prob in "start-up"
    pm = rep(NA, n), # prob in "routine"
    pl = rep(NA, n)  # prob in "manual"
)

P2014$ph[1] = 1
P2014$pm[1] = 0
P2014$pl[1] = 0
P2014$ph[2] = 1 - lhm1
P2014$pm[2] = lhm1
P2014$pl[2] = 0

for (i in 3:n){
    P2014$ph[i] = (1 - lhm1)^(i-1)
    temp = 0 # initialization
    for (v in 1:(i-1)){
        temp = temp + (1 - lhm1)^(v - 1)*lhm1*(1 - lml1)^(i - v - 1)
    }
    P2014$pm[i] = temp
    P2014$pl[i] = 1 - P2014$ph[i] - P2014$pm[i]

}

## export
write.table(P2014, file = "./outputs/P2014.txt")


## for the first quantitative exercise ----------------------------------------
lhm1 <- 0.00034 # 2014 level
lml1 <- 0.00578 # 2000 level

n <- 6000 # a large number of periods (years)
P_lhm <- data.frame(
    ph = rep(NA, n), # prob in "start-up"
    pm = rep(NA, n), # prob in "routine"
    pl = rep(NA, n)  # prob in "manual"
)

P_lhm$ph[1] = 1
P_lhm$pm[1] = 0
P_lhm$pl[1] = 0
P_lhm$ph[2] = 1 - lhm1
P_lhm$pm[2] = lhm1
P_lhm$pl[2] = 0

for (i in 3:n){
    P_lhm$ph[i] = (1 - lhm1)^(i-1)
    temp = 0 # initialization
    for (v in 1:(i-1)){
        temp = temp + (1 - lhm1)^(v - 1)*lhm1*(1 - lml1)^(i - v - 1)
    }
    P_lhm$pm[i] = temp
    P_lhm$pl[i] = 1 - P_lhm$ph[i] - P_lhm$pm[i]
}

## export
write.table(P_lhm, file = "./outputs/P_lhm.txt")


## for the second quantitative exercise ---------------------------------------
lhm1 <- 0.00117 # 2000 level
lml1 <- 0.00560 # 2014 level

n <- 6000 # a large number of periods (years)
P_lml_exp <- data.frame(
    ph = rep(NA, n), # prob in "start-up"
    pm = rep(NA, n), # prob in "routine"
    pl = rep(NA, n)  # prob in "manual"
)

## specify some probs
P_lml_exp$ph[1] = 1
P_lml_exp$pm[1] = 0
P_lml_exp$pl[1] = 0
P_lml_exp$ph[2] = 1 - lhm1
P_lml_exp$pm[2] = lhm1
P_lml_exp$pl[2] = 0

for (i in 3:n){
    P_lml_exp$ph[i] = (1 - lhm1)^(i-1)

    temp = 0 # initialization
    for (v in 1:(i-1)){
        temp = temp + (1 - lhm1)^(v - 1)*lhm1*(1 - lml1)^(i - v - 1)
    }
    P_lml_exp$pm[i] = temp

    P_lml_exp$pl[i] = 1 - P_lml_exp$ph[i] - P_lml_exp$pm[i]

}

## export
write.table(P_lml_exp, file = "./outputs/P_lml.txt")


end_time <- Sys.time()
end_time - start_time
