## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu                                                           ##
##     last modified:  JUNE 2021                                              ##
## -------------------------------------------------------------------------- ##

## exercise: An AR(1) shock on *lml*, which gradually reduces the value from its
## 2000 (calibrated) level to its 2014 (calibrated) level

## the algorithm
## 1. calculate the starting BGP and the ending BGP
## 2. specify the shock
##    2.1 specify the AR(1) process
## 3. choose a very long period of time, TR (= 500 here)
## 4. guess an initial policy tuple (g, thetahm, thetaml) for TR periods
## 5. generate state variables using the guessed policies
## 6. solve for the policy for period 51, using the guess-implied "future"
## 7. solve for the policy for period 52, ... , in the same fashion
## 8a)if the solved policy sequence is close enough to the guess, stop
## 8b)if not, update the guesses with solved policy (i.e., a weighted average)
##
## iterate until the solved policy is closed enough to the guess
## the tol = 1*10^(-5) here

## NOTE: for an easier implementation of the loop, in the following code, I
## assume the shock arrives at the end of period 50 instead of period 1 in the
## paper. In other words the economy operates at the 2000 BGP level for the
## first 49 periods. It is only relabelling the time period so that the essence
## of the analysis in the paper remains intact.

start_time <- Sys.time()

getwd()
library(rootSolve) # the library is for solving non-linear equation systems

## load the equations
source("./model.R")

## load the parameters --------------------------------------------------------- ##
## externally determined ones
a       <- 0.8 # elasticity of substitution
T       <- 45  # active years of workers, 20 to 64
L       <- 4.6 # average EU labour force = 207 mil, WDI world bank
rho     <- 0.04 # subjective discount factor (annual), g = r - \rho
thetalb <- 0    # lowest training cost level (normalization)

## calibrated ones
eta     <- 0.00255  # the inverse of the cost of product innovation
lhm     <- 0.00117  # rate from start-up to routine
lml     <- 0.00578  # rate from routine to manual
    lml0    <- 0.00578 # will be useful later
mu      <- 8.5  # how costly is the High-skilled training relative to the Middle-skilled training
thetaub <- 2.90 # highest training cost level

## calculate SS 2000, discrete time version ------------------------------------ ##
p0d <- c(0.02, 0.6*thetaub, 0.3*thetaub) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqmd0 <- multiroot(f = eqmd, start = p0d)
eqmd0

gd0 <- eqmd0$root[1]
thetamld0 <- eqmd0$root[2]
thetahmd0 <- eqmd0$root[3]
## need to check if the learning is affordable, for the critical individuals at least
wlhatd0 <- wlhat(gd0, thetamld0, thetahmd0)
wmhatd0 <- wmhat(gd0, thetamld0, thetahmd0)
whhatd0 <- whhat(gd0, thetamld0, thetahmd0)
yhatd0 <- yhat(gd0, thetamld0, thetahmd0)
chatd0 <- yhatd0*L*T - gd0/eta - ILhat(thetamld0, thetahmd0)
tauld0 <- taul(thetamld0)
taumd0 <- taum(thetamld0, thetahmd0)
tauhd0 <- tauh(thetahmd0)
ilhatd0 <- ILhat(thetamld0, thetahmd0)
resultsd = matrix(NA, nrow = 16, ncol = 1)
df2d = as.data.frame(resultsd) # this is the table that store the results
row.names(df2d) <- c("a", "thetalb", "L", "T", "lhm", "lml", "thetaub", "mu",
                   "eta", "rho", "g*", "whom*", "wmol*",
                   "tauh*", "taum*", "taul*")
colnames(df2d)[1] = c("bl2002d")
df2d$bl2002d <- c(a, thetalb, L, T, lhm, lml, thetaub, mu, eta, rho, gd0,
           whhatd0/wmhatd0, wmhatd0/wlhatd0, tauhd0, taumd0, tauld0)
df2d

## double checking some identities to verify the results ----------------------- ##
ltwhhatd0 <- 0 # initialization
ltwmhatd0 <- 0
ltwlhatd0 <- 0
rssd <- gd0 + rho
for (z in 1:T){
    ltwhhatd0 <- ltwhhatd0 + whhatd0*(1 + gd0)^(z-1)/(1 + rssd)^(z) 
    ltwmhatd0 <- ltwmhatd0 + wmhatd0*(1 + gd0)^(z-1)/(1 + rssd)^(z) 
    ltwlhatd0 <- ltwlhatd0 + wlhatd0*(1 + gd0)^(z-1)/(1 + rssd)^(z) 
}
ltwhhatd0
ltwmhatd0
ltwlhatd0

whhat(gd0, thetamld0, thetahmd0)*(1/(1+rssd))*(1 - ((1+gd0)/(1+rssd))^T)/(1 - (1+gd0)/(1+rssd))
wmhat(gd0, thetamld0, thetahmd0)*(1/(1+rssd))*(1 - ((1+gd0)/(1+rssd))^T)/(1 - (1+gd0)/(1+rssd))
wlhat(gd0, thetamld0, thetahmd0)*(1/(1+rssd))*(1 - ((1+gd0)/(1+rssd))^T)/(1 - (1+gd0)/(1+rssd))
## all checked up

P <- read.table(file = "./outputs/P2000.txt")
## second need to figure out WH, WM, and WL
WHd <- 0 # initialization
WMd <- 0
WLd <- 0
pihssd <- pih(gd0, thetamld0, thetahmd0)
pimssd <- pim(gd0, thetamld0, thetahmd0)
pilssd <- pil(gd0, thetamld0, thetahmd0)
ll <- 300
for (z in 1:ll){
    WHd <- WHd + P[z,1]*pihssd/(1 + rssd)^(z)
    WMd <- WMd + P[z,2]*pimssd/(1 + rssd)^(z)
    WLd <- WLd + P[z,3]*pilssd/(1 + rssd)^(z)
}
WHd + WMd + WLd # ll = 300 years seems to be long enough for the [limited] planning horizon of the firms
1/eta

## export the 2000 SS results -------------------------------------------------- ##
ssd <- data.frame(
    chih(gd0),                                            
    chim(gd0),                                             
    tauhd0,                                               
    taumd0,                                               
    gd0,                                                  
    gd0 + rho,                                            
    yhatd0*L*T - gd0/eta - ILhat(thetamld0, thetahmd0),      
    thetahmd0,                                            
    thetamld0
)
colnames(ssd) <- c(
     "chih_ssd",
     "chim_ssd",
     "tauh_ssd",
     "taum_ssd",
     "g_ssd",   
     "r_ssd",   
     "chat_ssd",
     "thm_ssd",
     "tml_ssd" 
)


## calculate the new steady state with lml = 0.00560 ------------------------ ##
## load parameters
lml <- 0.00560  # rate from routine to manual
    lml1 <- 0.00560  # will be useful later

## re calculate initial guess p0 here
p0 <- c(0.02, 0.6*thetaub, 0.3*thetaub ) #  p[1] = g; p[2] = thetaml; p[3] = thetahm
eqmd1 <- multiroot(f = eqmd, start = p0)
eqmd1
gd1 <- eqmd1$root[1]
thetamld1 <- eqmd1$root[2]
thetahmd1 <- eqmd1$root[3]
## need to check if the learning is affordable, for the critical individuals at least
wlhatd1 <- wlhat(gd1, thetamld1, thetahmd1)
wmhatd1 <- wmhat(gd1, thetamld1, thetahmd1)
whhatd1 <- whhat(gd1, thetamld1, thetahmd1)
yhatd1 <- yhat(gd1, thetamld1, thetahmd1)
tauld1 <- taul(thetamld1)
taumd1 <- taum(thetamld1, thetahmd1)
tauhd1 <- tauh(thetahmd1)
ilhatd1 <- ILhat(thetamld1, thetahmd1)
lfwhhatd1 <- whhatd1*exp(gd1*T - 1)/gd1 # life time income of H, enters at time 0
lfwmhatd1 <- wmhatd1*exp(gd1*T - 1)/gd1 # life time income of M, enters at time 0
lfwlhatd1 <- wlhatd1*exp(gd1*T - 1)/gd1 # life time income of L, enters at time 0
results = matrix(NA, nrow = 16, ncol = 1)
df3 = as.data.frame(results) # this is the table that store the results
row.names(df3) <- c("a", "thetalb", "L", "T", "lhm", "lml", "thetaub", "mu",
                   "eta", "rho", "g*", "whom*", "wmol*",
                   "tauh*", "taum*", "taul*")
colnames(df3)[1] = c("bl2014")
df3$bl2014 <- c(a, thetalb, L, T, lhm, lml, thetaub, mu, eta, rho, gd1,
           whhatd1/wmhatd1, wmhatd1/wlhatd1, tauhd1, taumd1, tauld1)
df3

## double checking some identities to verify the results ----------------------- ##
ltwhhatd1 <- 0 # initialization
ltwmhatd1 <- 0
ltwlhatd1 <- 0
rssd1 <- gd1 + rho
for (z in 1:T){
    ltwhhatd1 <- ltwhhatd1 + whhatd1*(1 + gd1)^(z-1)/(1 + rssd1)^(z) 
    ltwmhatd1 <- ltwmhatd1 + wmhatd1*(1 + gd1)^(z-1)/(1 + rssd1)^(z) 
    ltwlhatd1 <- ltwlhatd1 + wlhatd1*(1 + gd1)^(z-1)/(1 + rssd1)^(z) 
}
ltwhhatd1
ltwmhatd1
ltwlhatd1

whhat(gd1, thetamld1, thetahmd1)*(1/(1+rssd1))*(1 - ((1+gd1)/(1+rssd1))^T)/(1 - (1+gd1)/(1+rssd1))
wmhat(gd1, thetamld1, thetahmd1)*(1/(1+rssd1))*(1 - ((1+gd1)/(1+rssd1))^T)/(1 - (1+gd1)/(1+rssd1))
wlhat(gd1, thetamld1, thetahmd1)*(1/(1+rssd1))*(1 - ((1+gd1)/(1+rssd1))^T)/(1 - (1+gd1)/(1+rssd1))
## all checked up

P_lml <- read.table(file = "./outputs/P_lml.txt")
## second need to figure out WH, WM, and WL
WHd1 <- 0 # initialization
WMd1 <- 0
WLd1 <- 0
pihssd1 <- pih(gd1, thetamld1, thetahmd1)
pimssd1 <- pim(gd1, thetamld1, thetahmd1)
pilssd1 <- pil(gd1, thetamld1, thetahmd1)
## ll <- nrow(P)
for (z in 1:ll){
    WHd1 <- WHd1 + P_lml[z,1]*pihssd1/(1 + rssd1)^(z)
    WMd1 <- WMd1 + P_lml[z,2]*pimssd1/(1 + rssd1)^(z)
    WLd1 <- WLd1 + P_lml[z,3]*pilssd1/(1 + rssd1)^(z)
}
WHd1 + WMd1 + WLd1 # it works!!!
1/eta

## export the 2014 SS results -------------------------------------------------- ##
ssd1 <- data.frame(
    chih(gd1),                                            
    chim(gd1),                                             
    tauhd1,                                               
    taumd1,                                               
    gd1,                                                  
    gd1 + rho,                                            
    yhatd1*L*T - gd1/eta - ILhat(thetamld1, thetahmd1),      
    thetahmd1,                                            
    thetamld1
)
colnames(ssd1) <- c(
     "chih_ssd1",
     "chim_ssd1",
     "tauh_ssd1",
     "taum_ssd1",
     "g_ssd1",   
     "r_ssd1",   
     "chat_ssd1",
     "thm_ssd1",
     "tml_ssd1" 
)
## -------------------------------------------------------------------------- ## 




## set up the data frame for storing results -------------------------------- ##
## the shock arrives at (the end of) period 50
TR = 550 # it takes 400 periods, from the shock period, to reach the new ss,
         # assuming that the economy operates at the original ss in the first 50
         # periods
F = 350  # how many periods the economy would last after reaching the new ss
## so the economy lasts for 1200 periods in total

trm <- data.frame(
    chih = rep(NA, TR + F), # proportion of "start-up" firms
    chim = rep(NA, TR + F), # proportion of "mass production" firms
    tauh = rep(NA, TR + F), # proportion of High-skilled workers
    taum = rep(NA, TR + F), # proportion of Middle-skilled workers
    g = rep(NA, TR + F),    # the growth rate
    r = rep(NA, TR + F),    # the interest rate
    chat = rep(NA, TR + F), # per-capita consumption
    thm = rep(NA, TR + F),  # cutoff between High- and Middle-skilled workers
    tml = rep(NA, TR + F)   # cutoff between Middle- and Low-skilled workers
)

trm[TR:(TR+F),] <- ssd1 # the "new" steady state
trm[1:50, ] <- ssd # the "old" steady states 2000

## Add four aux variables in trm
trm$Vf <- rep(NA, TR + F) # Aux variable in eqn 9
trm$ltwhhat <- rep(NA, TR + F) # Aux variable in eqn 5 and 6
trm$ltwmhat <- rep(NA, TR + F) # Aux variable in eqn 5 and 6
trm$ltwlhat <- rep(NA, TR + F) # Aux variable in eqn 5 and 6

## some functions can be defined outside the loop
yz <- function(chih, chim, tauh, taum){ # p1, p2, p3, p4
    ((1 - chih - chim)^(1-a)*(1 - tauh - taum)^a + chim^(1-a)*taum^a + chih^(1-a)*tauh^a)^(1/a)
}
ILzhat <- function(tauh, taum, thm, tml){ # p3, p4, p5, p6
    0.5*L*(tauh*thm*mu + (thm + tml)*taum)
}
whzhat <- function(chih, chim, tauh, taum){
    a*yz(chih, chim, tauh, taum)^(1-a)*(chih/tauh)^(1-a)
}
wmzhat <- function(chih, chim, tauh, taum){
    a*yz(chih, chim, tauh, taum)^(1-a)*(chim/taum)^(1-a)
}
wlzhat <- function(chih, chim, tauh, taum){
    a*yz(chih, chim, tauh, taum)^(1-a)*((1 - chih - chim)/(1 - tauh - taum))^(1-a)
}

pihz <- function(chih, chim, tauh, taum){
    (1 - a)*yz(chih, chim, tauh, taum)^(1 - a)*(chih/tauh)^(-a)*L*T
}
pimz <- function(chih, chim, tauh, taum){
    (1 - a)*yz(chih, chim, tauh, taum)^(1 - a)*(chim/taum)^(-a)*L*T
}
pilz <- function(chih, chim, tauh, taum){
    chil = 1 - chih - chim
    taul = 1 - tauh - taum
    (1 - a)*yz(chih, chim, tauh, taum)^(1 - a)*(chil/taul)^(-a)*L*T
}

## specify the shock process ----------------------------------------------- ##
trm$lhm <- rep(lhm, TR + F) # lhm doesn't change in this exercise
trm$lml <- NA
trm$lml[1:49] <- lml0 # before the shock
trm$lml[TR:(TR+F)] <- lml1 # after the shock
phi = 0.7
for (i in 50:TR){ # during the shock, the gradual change
    trm$lml[i] <- (1 - phi)*lml1 + phi*trm$lml[i-1]
}
## specify the shock process ----------------------------------------------- ##

## uncomment this block if running for the first time ---------------------- ##

## this block calculates a series of transitional matrices, as lml is declining
## every period, the entrants face different transtional matrices
## take a look at the number of "transitional" period here
trm$lml[49:80]

Ptrans <- list(a) # create a list to append later
n <- 350
for (j in 51:78){ # each j is a transitional matrix for firms enter at the beginning of period j

    ## need to adjust the transitional matrix P accordingly here
    P_grad <- data.frame(
        ph = rep(NA, n), # prob in "start-up"
        pm = rep(NA, n), # prob in "mass production"
        pl = rep(NA, n)  # prob in "routine"
    )
    ## specify some probs (the comments are for j = 51, and the rest is similar)
    P_grad$ph[1] = 1 # enters at period 51, will stay "start-up" in period 51
    P_grad$pm[1] = 0
    P_grad$pl[1] = 0

    P_grad$ph[2] = 1 - trm$lhm[j] # period 52, using the period 51 transition rate
    P_grad$pm[2] = trm$lhm[j]
    P_grad$pl[2] = 0

    P_grad$ph[3] = (1 - trm$lhm[j])*(1 - trm$lhm[j+1]) # period 53
    P_grad$pm[3] = trm$lhm[j]*(1 - trm$lml[j+1]) +  (1 - trm$lhm[j])*trm$lhm[j+1]
    P_grad$pl[3] = 1 - P_grad$ph[3] - P_grad$pm[3]

    for (i in 4:n){
        print(paste("this is for period", j, "loop no.", i))
        temp_ph = 1
        for (v in 1:(i - 1)){
            temp_ph = temp_ph*(1 - trm$lhm[j + v - 1])
        }
        P_grad$ph[i] = temp_ph

        temp_pm_first <- trm$lhm[j]
        for (v in 2:(i - 1)){
            temp_pm_first <- temp_pm_first*(1 - trm$lml[j + v - 1])
        }
        temp_pm_last <- trm$lhm[j + i - 2]
        for (v in 1:(i - 2)){
            temp_pm_last <- temp_pm_last*(1 - trm$lhm[j + v - 1])
        }
        temp_pm_middle <- 0
        for (v in 2:(i - 2)){
            PR = 1 # pre-term
            for (w in 1:(v - 1)){
                PR = PR*(1 - trm$lhm[j + w - 1])
            }
            PT = 1 # post-term
            for (w in (v + 1):(i - 1)){
                PT = PT*(1 - trm$lml[j + w - 1])
            }
            temp_pm_middle = temp_pm_middle + PR*trm$lhm[j + v - 1]*PT
        }

        P_grad$pm[i] = temp_pm_first + temp_pm_middle + temp_pm_last

        P_grad$pl[i] = 1 - P_grad$ph[i] - P_grad$pm[i]

    }
    Ptrans[[j - 50]] <- P_grad
} # end of the j loop

## double check
(1-0.00117)^3
0.00117*(1-0.00566174)*(1-0.00564322)+(1-0.00117)*0.00117*(1-0.00564322)+(1-0.00117)*(1-0.00117)*0.00117 # Ptrans[[1]][4,2]
0.00117*(1-0.00564322)*(1-0.00563025)+(1-0.00117)*0.00117*(1-0.00563025)+(1-0.00117)*(1-0.00117)*0.00117 # Ptrans[[2]][4,2]

## add the rest identical transition matrices to Ptrans
for (i in 29:TR){
    Ptrans[[i]] <- P_lml # so Ptrans is a list of 250 transition matrices
}

## export
saveRDS(object = Ptrans, file = "./outputs/Ptrans_lml.rds")
## uncomment this block if running for the first time ---------------------- ##

## load the list of transition martrices 
Ptrans <- readRDS(file = "./outputs/Ptrans_lml.rds")

## specifiy the initial guess for 200 periods/years
newguess <- data.frame(
    g <- rep(gd1*1.00, (TR - 50)),
    tml <- rep(thetamld1*1.00, (TR - 50)),
    thm <- rep(thetahmd1*1.00, (TR - 50))
)
colnames(newguess) <- c("g", "tml", "thm")

tol = 1*10^(-5) # set the convergence criterion here
for (i in 1:100){

    ## put the new guesses to the trm data.frame
    trm$g[51:TR] <- newguess$g
    trm$tml[51:TR] <- newguess$tml
    trm$thm[51:TR] <- newguess$thm                                            
    
    ## implied firm distribution and skill distribution
    for (z in 51:TR){
        trm$chih[z] <- (1 - trm$lhm[z - 1])*trm$chih[z - 1]/(1 + trm$g[z - 1]) + trm$g[z - 1]/(1 + trm$g[z - 1])
        trm$chim[z] <- (1 - trm$lml[z - 1])*trm$chim[z - 1]/(1 + trm$g[z - 1]) + trm$lhm[z - 1]*trm$chih[z - 1]/(1 + trm$g[z - 1])
        trm$tauh[z] <- sum(tauh(trm$thm[(z-T+1):z]))/T
        trm$taum[z] <- sum(taum(trm$tml[(z-T+1):z], trm$thm[(z-T+1):z]))/T
        trm$chat[z] <- yz(trm$chih[z], trm$chim[z], trm$tauh[z], trm$taum[z])*L*T - ILzhat(trm$tauh[z], trm$taum[z], trm$thm[z], trm$tml[z]) - trm$g[z]/eta
    }

    for (z in 51:TR){
        trm$r[z] <- (trm$chat[z+1] - trm$chat[z])/trm$chat[z] + rho + trm$g[z]
    }
    trm$r[TR] <- rssd1

    ## solve for the transitional period z, starting from period 51
    for (z in 51:TR){ # beginning of the loop
        print(paste("this is simulation", i, ", iternation:", z))

        ## variable list
        ## p[1] = tauh; p[2] = taum; p[3] = thm; p[4] = tml;
        ## p[5] = g; p[6] = r; p[7] = chat;

        ## ## chih and chim are predetermined
        trm$chih[z] <- (1 - trm$lhm[z - 1])*trm$chih[z - 1]/(1 + trm$g[z - 1]) + trm$g[z - 1]/(1 + trm$g[z - 1])
        trm$chim[z] <- (1 - trm$lml[z - 1])*trm$chim[z - 1]/(1 + trm$g[z - 1]) + trm$lhm[z - 1]*trm$chih[z - 1]/(1 + trm$g[z - 1])


        ## ------------------------------------------------------------------ ##
        yzl <- function(tauh, taum){ # these functions with an "l" at the end
                                     # denotes functions used in the "loop" and
                                     # will be redefined in every loop
            ((1 - trm$chih[z] - trm$chim[z])^(1-a)*(1 - tauh - taum)^a + trm$chim[z]^(1-a)*taum^a + trm$chih[z]^(1-a)*tauh^a)^(1/a)
        }
        whzhatl <- function(tauh, taum){
            a*yzl(tauh, taum)^(1-a)*(trm$chih[z]/tauh)^(1-a)
        }
        wmzhatl <- function(tauh, taum){
            a*yzl(tauh, taum)^(1-a)*(trm$chim[z]/taum)^(1-a)
        }
        wlzhatl <- function(tauh, taum){
            a*yzl(tauh, taum)^(1-a)*((1 - trm$chih[z] - trm$chim[z])/(1 - tauh - taum))^(1-a)
        }

        pihzl <- function(tauh, taum){
            (1 - a)*yzl(tauh, taum)^(1 - a)*(trm$chih[z]/tauh)^(-a)*L*T
        }
        ## ------------------------------------------------------------------ ##

        
        eqn3 <- function(tauh, thm){ # p1, p3
            (thm - trm$thm[z - T]) - T*(thetaub - thetalb)*(tauh - trm$tauh[z - 1]) # eqn (3) 
        }
        eqn4 <- function(taum, thm, tml){ # p2, p3, p4
            (tml - trm$tml[z - T]) - (thm - trm$thm[z - T]) - T*(thetaub - thetalb)*(taum - trm$taum[z - 1]) #eqn (4)
        }
        eqn7 <- function(tauh, taum, thm, tml, g, chat){ # p1, p2, p3, p4, p5, p7
            eta*(yzl(tauh, taum)*L*T - chat - ILzhat(tauh, taum, thm, tml)) - g # eqn (7)
        }
        eqn8 <- function(g, r, chat){                 # p5, p6, p7
            r - rho - g - (trm$chat[z+1] - chat)/chat # eqn 8
        }
        ## eqn 5 and 6
        whtemp = 0 # initialize, calculate "life time income" along the transition path
        wmtemp = 0 # initialize
        wltemp = 0 # initialize
        for (v in (z+2):(z+T-1)){ # starts from the z+2 term
            RR = 1
            for (xi in (z+1):v){
                RR = RR*(1 + trm$r[xi])
            }
            GG = 1
            for (xi in (z+1):(v-1)){
                GG = GG*(1 + trm$g[xi])
            }
            whtemp = whtemp + whzhat(trm$chih[v], trm$chim[v], trm$tauh[v], trm$taum[v])*GG/RR
            wmtemp = wmtemp + wmzhat(trm$chih[v], trm$chim[v], trm$tauh[v], trm$taum[v])*GG/RR
            wltemp = wltemp + wlzhat(trm$chih[v], trm$chim[v], trm$tauh[v], trm$taum[v])*GG/RR
        }
        ## add the z+1 term
        trm$ltwhhat[z] <- whtemp + whzhat(trm$chih[z+1], trm$chim[z+1], trm$tauh[z+1], trm$taum[z+1])/(1 + trm$r[z+1])
        trm$ltwmhat[z] <- wmtemp + wmzhat(trm$chih[z+1], trm$chim[z+1], trm$tauh[z+1], trm$taum[z+1])/(1 + trm$r[z+1])
        trm$ltwlhat[z] <- wltemp + wlzhat(trm$chih[z+1], trm$chim[z+1], trm$tauh[z+1], trm$taum[z+1])/(1 + trm$r[z+1])
        eqn5 <-  function(tauh, taum, thm, g, r){ # p1, p2, p3, p5, p6
            (whzhatl(tauh, taum) + (1+g)*trm$ltwhhat[z] - wmzhatl(tauh, taum) - (1+g)*trm$ltwmhat[z]) - thm*(mu - 1)*(1 + r)
        }
        eqn6 <-  function(tauh, taum, tml, g, r){ # p1, p2, p4, p5, p6
            (wmzhatl(tauh, taum) + (1+g)*trm$ltwmhat[z] - wlzhatl(tauh, taum) - (1+g)*trm$ltwlhat[z]) - tml*(1 + r)
        }
        
        Vztemp = 0 # initialization
        for (v in 2:300){ # I assume when firms calculating value of entry will only consider 300 periods
            RR = 1
            for (xi in 1:(v-1)){
                RR = RR*(1 + trm$r[z+xi]) # calculate the discount factor for each period v
            }   
            pihv = pihz(chih = trm$chih[z+v-1], chim = trm$chim[z+v-1], tauh = trm$tauh[z+v-1], taum = trm$taum[z+v-1])
            pimv = pimz(chih = trm$chih[z+v-1], chim = trm$chim[z+v-1], tauh = trm$tauh[z+v-1], taum = trm$taum[z+v-1])
            pilv = pilz(chih = trm$chih[z+v-1], chim = trm$chim[z+v-1], tauh = trm$tauh[z+v-1], taum = trm$taum[z+v-1])
            Vztemp = Vztemp + Ptrans[[z-50]][v,1]*pihv/RR + Ptrans[[z-50]][v,2]*pimv/RR + Ptrans[[z-50]][v,3]*pilv/RR
        }
        trm$Vf[z] = Vztemp
        eqn9 <- function(tauh, taum, r){ # p1, p2, p6
            pihzl(tauh, taum)/(1 + r) + trm$Vf[z]/(1 + r) - 1/eta
        }
        ## setup the eqmz here
        trmf <- function(p){ ## p[1] = tauh; p[2] = taum; p[3] = thm; p[4] =
                             ## tml; p[5] = g; p[6] = r; p[7] = chat;
            c(eqn3(p[1], p[3]),       # changing the labour force composition
              eqn4(p[2], p[3], p[4]), # changing the labour force composition
              eqn7(p[1], p[2], p[3], p[4], p[5], p[7]), # final goods market equilibrium condition
              eqn8(p[5], p[6], p[7]),                   # euler equation
              eqn5(p[1], p[2], p[3], p[5], p[6]),       # thm equation
              eqn6(p[1], p[2], p[4], p[5], p[6]),       # tml equation
              eqn9(p[1], p[2], p[6])                    # free entry
              )}
        p0 <- as.numeric(c(trm[z - 1,3:4], trm[z - 1,8:9], trm[z - 1,5:7])) # guess the steady state values
        eqmz <- multiroot(f = trmf, start = p0)
        eqmz
        trm[z,3:4] <- eqmz$root[1:2] # tauh, taum
        trm[z,8:9] <- eqmz$root[3:4] # thm, tml
        trm[z,5:7] <- eqmz$root[5:7] # g, r, chat

        print(paste("chih = ", trm$chih[z]))
        print(paste("chim = ", trm$chim[z]))
        print(paste("tauh = ", eqmz$root[1]))
        print(paste("taum = ", eqmz$root[2]))
        print(paste("thetaHM = ", eqmz$root[3]))
        print(paste("thetaML = ", eqmz$root[4]))
        print(paste("g = ", eqmz$root[5]))
        print(paste("r = ", eqmz$root[6]))
        print(paste("chat = ", eqmz$root[7]))

    } # end of "z" loop

    write.table(trm[1:(TR+100),], file = paste("./outputs/trm_lml_", i, ".txt", sep = ""))

    if (i > 1){
        ## check the convergence criteria here
        thisIteration <- trm[1:(TR+100),]
        lastIteration <- read.table(file = paste("./outputs/trm_lml_", i-1, ".txt", sep = ""))
        
        toll <- max(c(max(thisIteration$g - lastIteration$g),
                      max(thisIteration$thm - lastIteration$thm),
                      max(thisIteration$tml - lastIteration$tml)))
        if (toll < tol) {
            print(paste("we have converged after iteration ", i, "!", sep = ""))
            break
        }
    }
    
    oldguess <- newguess # record the current guesses here

    newguess <- data.frame( # update the new guesses
        oldguess$g*0.95 + trm$g[51:TR]*0.05,
        oldguess$tml*0.95 + trm$tml[51:TR]*0.05,
        oldguess$thm*0.95 + trm$thm[51:TR]*0.05
    )
    colnames(newguess) <- c("g", "tml", "thm")
    
} # End of the "i" loop

end_time <- Sys.time()
end_time - start_time


## ----------------------------------------------------------------------------
## plot the result of the transitional dynamics analysis
## ----------------------------------------------------------------------------

lml41 <- read.table(file = "./outputs/trm_lml_41.txt")
lml40 <- read.table(file = "./outputs/trm_lml_40.txt")

max(lml41$g - lml40$g)
max(lml41$thm - lml40$thm)
max(lml41$tml - lml40$tml)


## plot the AR(1) shock of lml
pdf(file = "./figs/lml_lml41.pdf")
plot(lml41$lml[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "Poisson rate of process innovation \nfrom routine to manual", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = lml41$lml[69]*0.9992, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(min(lml41$lml)*0.9992,6), cex.axis = 2)
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(min(lml41$lml)*0.9992,6), cex.axis = 2)
axis(2, at = lml41$lml[49], labels = "0.00578", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = lml41$lml[69], labels = "          0.00560", las = 0, pos = 1.2, cex.axis = 1.5)
dev.off()


## plot g
pdf(file = "./figs/lml_g41.pdf")
plot(lml41$g[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The growth rate", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = min(lml41$g[49:69])*0.999988, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(min(lml41$g[49:69])*0.999988,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(min(lml41$g[49:69])*0.999988,6), cex.axis = 2 )
axis(2, at = lml41$g[49], labels = "1.869%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = lml41$g[51], labels = "        1.868%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()


## plot wh/wm
whom41 <- whzhat(lml41$chih, lml41$chim, lml41$tauh, lml41$taum)/wmzhat(lml41$chih, lml41$chim, lml41$tauh, lml41$taum)
pdf(file = "./figs/lml_whom41.pdf")
plot(whom41[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The skill premium of high-skilled \nrelative to middle-skilled workers", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = whom41[49]*0.9999985, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(min(whom41[49:69])*0.9999985,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(min(whom41[49:69])*0.9999985,6), cex.axis = 2 )
axis(2, at = whom41[49], labels = "       1.7807", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = whom41[69], labels = "1.7808", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()


## plot wm/wl
wmol41 <- wmzhat(lml41$chih, lml41$chim, lml41$tauh, lml41$taum)/wlzhat(lml41$chih, lml41$chim, lml41$tauh, lml41$taum)
pdf(file = "./figs/lml_wmol41.pdf")
plot(wmol41[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The skill premium of middle-skilled \nrelative to low-skilled workers", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = wmol41[49]*0.999975, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(wmol41[49]*0.999975,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(wmol41[49]*0.999975,6), cex.axis = 2 )
axis(2, at = wmol41[49], labels = "    1.239", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = wmol41[69], labels = "1.240", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()


## plot tauh
pdf(file = "./figs/lml_tauh41.pdf")
plot(lml41$tauh[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The share of high-skilled workers", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = lml41$tauh[49]*0.999998, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(lml41$tauh[49]*0.999998,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(lml41$tauh[49]*0.999998,6), cex.axis = 2 )
axis(2, at = lml41$tauh[49], labels = "            38.028%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = lml41$tauh[69], labels = "38.031%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()


## plot taum
pdf(file = "./figs/lml_taum41.pdf")
plot(lml41$taum[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The share of middle-skilled workers", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = min(lml41$taum[49:69])*0.99993, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(lml41$taum[49]*0.99993,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(lml41$taum[49]*0.99993,6), cex.axis = 2 )
axis(2, at = lml41$taum[49], labels = "        32.5%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = lml41$taum[69], labels = "32.6%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()


## plot thetaHM
pdf(file = "./figs/lml_thetahm41.pdf")
plot(lml41$thm[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The type cut-off between high-skilled \nand middle-skilled workers", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = lml41$thm[49]*0.999994, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(min(lml41$thm[49:69])*0.999994,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(min(lml41$thm[49:69])*0.999994,6), cex.axis = 2 )
axis(2, at = lml41$thm[49], labels = "        1.1028", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = lml41$thm[69], labels = "1.1031", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()


## plot thetaML
pdf(file = "./figs/lml_thetaml41.pdf")
plot(lml41$tml[49:69], type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The type cut-off between middle-skilled \nand low-skilled workers", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = lml41$tml[49]*0.9999, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(min(lml41$tml[49:69])*0.9999,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(min(lml41$tml[49:69])*0.9999,6), cex.axis = 2 )
axis(2, at = lml41$tml[49], labels = "      2.047", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = lml41$tml[69], labels = "2.054", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()


## ## plot chat
## pdf(file = "./figs/lml_chat41.pdf")
## plot(lml41$chat[49:69], type = "p", pch = 19, cex = 1, col = "blue",
##      ylab = "",
##      xlab = "",
##      xaxt = "n",
##      yaxt = "n",
##      bty = "n"
## )
## title(ylab="The c-hat", line=0.7, cex.lab=1.2)
## title(xlab="Periods", line=1.5, cex.lab=1.2)
## abline(v = 1, lwd = 2) # vertical axis
## abline(h = lml41$chat[69]*0.999996, lwd = 2) # horizontal axis
## axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = F, pos = rep(lml41$chat[69]*0.999996,6) )
## axis(2, at = lml41$chat[49], labels = "147.28", las = 0, tick = F, pos = 1.2)
## axis(2, at = lml41$chat[69], labels = "     147.25", las = 0, tick = F, pos = 1.2)
## dev.off()


## plot taul
taul41 <- 1 - lml41$tauh[49:69] - lml41$taum[49:69]
pdf(file = "./figs/lml_taul41.pdf")
plot(taul41, type = "p", pch = 19, cex = 2, col = "blue",
     ylab = "",
     xlab = "",
     xaxt = "n",
     yaxt = "n",
     bty = "n"
)
title(main = "The share of low-skilled workers", cex.main=2, family = "serif")
title(xlab="Periods", line=1.5, cex.lab=1.5)
abline(v = 1, lwd = 3) # vertical axis
abline(h = taul41[21]*0.99992, lwd = 3) # horizontal axis
axis(1, at = c(1,2,6,11,16,21), labels = c(0,1,5,10,15,20), las = 1, tick = T, pos = rep(taul41[21]*0.99992,6), cex.axis = 2 )
axis(1, at = c(2), labels = c(1), las = 1, tick = T, pos = rep(taul41[21]*0.99992,6), cex.axis = 2 )
axis(2, at = taul41[1], labels = "29.4%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
axis(2, at = taul41[21], labels = "        29.3%", las = 0, tick = T, pos = 1.2, cex.axis = 1.5)
dev.off()
