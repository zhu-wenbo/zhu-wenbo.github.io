## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu                                                           ##
##     last modified:  JUNE 2021                                              ##
## -------------------------------------------------------------------------- ##

## this file retrieves the relevant data for calculating some of the calibration
## targets.

getwd()

library(dplyr)    # for various data manipulation

## ---------------------------------------------------------------------------
## get the data from Eurostat between 2002 and 2014
## ---------------------------------------------------------------------------

## library(eurostat) # for retrieving the raw data from Eurostat
## ## SES 2002
## ## number of employees by size of the enterprise, sex, and occupation
## ses03 <- get_eurostat("earn_ses_agt03", time_format = "raw", cache_dir = "./eurostat_RAWdata")
## ## annual earnings by occupation (and country)
## ses32 <- get_eurostat("earn_ses_agt32", time_format = "raw", cache_dir = "./eurostat_RAWdata")


## ## SES 2006
## ## number of employees by size class of the enterprise, sex, and occupation
## ses0653 <- get_eurostat("earn_ses06_53", time_format = "raw", cache_dir = "./eurostat_RAWdata")
## ## annual earnings by occupation (and country)
## ses0632 <- get_eurostat("earn_ses06_32", time_format = "raw", cache_dir = "./eurostat_RAWdata")


## ## SES 2010
## ## number of employees by sex age occupations and size class
## ses1053 <- get_eurostat("earn_ses10_53", time_format = "raw", cache_dir = "./eurostat_RAWdata")
## ## annual earnings by occupation (and country)
## ses1032 <- get_eurostat("earn_ses10_32", time_format = "raw", cache_dir = "./eurostat_RAWdata")


## ## SES 2014
## ## number of employees by sex age occupations and size class
## ses1453 <- get_eurostat("earn_ses14_53", time_format = "raw", cache_dir = "./eurostat_RAWdata")
## ## annual earnings by occupation (and country)
## ses1432 <- get_eurostat("earn_ses14_32", time_format = "raw", cache_dir = "./eurostat_RAWdata")

## load the downloaded data files
ses03   <- readRDS(file = "./eurostat_RAWdata/earn_ses_agt03_raw_code_TF.rds")
ses32   <- readRDS(file = "./eurostat_RAWdata/earn_ses_agt32_raw_code_TF.rds")
ses0653 <- readRDS(file = "./eurostat_RAWdata/earn_ses06_53_raw_code_TF.rds")
ses0632 <- readRDS(file = "./eurostat_RAWdata/earn_ses06_32_raw_code_TF.rds")
ses1053 <- readRDS(file = "./eurostat_RAWdata/earn_ses10_53_raw_code_TF.rds")
ses1032 <- readRDS(file = "./eurostat_RAWdata/earn_ses10_32_raw_code_TF.rds")
ses1453 <- readRDS(file = "./eurostat_RAWdata/earn_ses14_53_raw_code_TF.rds")
ses1432 <- readRDS(file = "./eurostat_RAWdata/earn_ses14_32_raw_code_TF.rds")


## ---------------------------------------------------------------------------
## calculating nominal wages for each occupation
## ---------------------------------------------------------------------------
## 2002
occw02 <- filter(ses32, sizeclas == "TOTAL", unit == "EUR", indic_se  == "AB" | indic_se == "AE",
                 sex == "T") %>%
  select(isco88, indic_se, geo, values)
occw02ab <- filter(occw02, indic_se == "AB") %>% select(isco88, indic_se, geo, values)
occw02ae <- filter(occw02, indic_se == "AE") %>% select(isco88, indic_se, geo, values)
occw02 <- data.frame(occw02ab$geo, occw02ab$isco88, occw02ab$values + occw02ae$values)
colnames(occw02) <- c("country", "occupation", "occw02")

## 2006
occw06 <- filter(ses0632, unit == "EUR", indic_se  == "AB" | indic_se == "AE",
                 sex == "T") %>%
  select(isco88, sizeclas, indic_se, geo, values)
occw06ab <- filter(occw06, indic_se == "AB") %>% select(isco88, sizeclas, indic_se, geo, values)
occw06ae <- filter(occw06, indic_se == "AE") %>% select(isco88, sizeclas, indic_se, geo, values)
occw06 <- data.frame(occw06ab$geo, occw06ab$isco88, occw06ab$sizeclas,
                     occw06ab$values + occw06ae$values)
colnames(occw06) <- c("country", "occupation", "sizeclas", "occw06")

## 2010
occw10 <- filter(ses1032, currency == "EUR", indic_se  == "AB" | indic_se == "AE",
                 sex == "T") %>%
  select(isco08, sizeclas, indic_se, geo, values)
occw10ab <- filter(occw10, indic_se == "AB") %>% select(isco08, sizeclas, indic_se, geo, values)
occw10ae <- filter(occw10, indic_se == "AE") %>% select(isco08, sizeclas, indic_se, geo, values)
occw10 <- data.frame(occw10ab$geo, occw10ab$isco08, occw10ab$sizeclas,
                     occw10ab$values + occw10ae$values)
colnames(occw10) <- c("country", "occupation", "sizeclas", "occw10")

## 2014
occw14 <- filter(ses1432, currency == "EUR", indic_se  == "AB" | indic_se == "AE",
                 sex == "T") %>%
  select(isco08, sizeclas, indic_se, geo, values)
occw14ab <- filter(occw14, indic_se == "AB") %>% select(isco08, sizeclas, indic_se, geo, values)
occw14ae <- filter(occw14, indic_se == "AE") %>% select(isco08, sizeclas, indic_se, geo, values)
occw14 <- data.frame(occw14ab$geo, occw14ab$isco08, occw14ab$sizeclas,
                     occw14ab$values + occw14ae$values)
colnames(occw14) <- c("country", "occupation", "sizeclas", "occw14")

## select the overall European situation
occw02f <- filter(occw02, country == "EU25")
occw06f <- filter(occw06, country == "EU27")
occw10f <- filter(occw10, country == "EU28")
occw14f <- filter(occw14, country == "EU28")

occw06fa <- occw06f %>% group_by(country, occupation) %>% summarize(occw06fa = mean(occw06))
occw10fa <- occw10f %>% group_by(country, occupation) %>% summarize(occw10fa = mean(occw10))
occw14fa <- occw14f %>% group_by(country, occupation) %>% summarize(occw14fa = mean(occw14))

occw02fa <- occw02f[,-1] # get rid of the country column
occw06fa <- occw06fa[,-1]
occw10fa <- occw10fa[,-1]
occw14fa <- occw14fa[,-1]

## unify the labeling for "occupation"
occlist02 <- c("OC0", "OC1", "OC1-5", "OC2", "OC3", "OC4", "OC5", "OC7", "OC7-9",
               "OC8", "OC9", "TOTAL", "UNK")
occlist06 <- c("OC0", "OC1", "OC1-5", "OC2", "OC3", "OC4", "OC5", "OC6", "OC7", "OC7-9",
               "OC8", "OC9", "TOTAL", "UNK")
occw02fa$occupation <- occlist02
occw06fa$occupation <- occlist06
table3 <- Reduce(function(x, y) merge(x, y, by = "occupation", all=TRUE),
                 list(occw02fa, occw06fa, occw10fa, occw14fa))

## remove some irrelevant rows
calibrationTargets_Wages <- table3[-c(3,10,14),]
## export the information
write.csv(calibrationTargets_Wages, file = "./tables/calibrationTargets_Wages.csv", row.names = F)



## --------------------------------------------------------------------- ##
## calculating employment shares for each occupation
## --------------------------------------------------------------------- ##

es02 <- filter(ses03, sizeclas == "TOTAL", sex == "T", geo == "EU25") %>%
  select(isco88, values)

es06 <- filter(ses0653, sex == "T", geo == "EU27") %>%
  select(sizeclas, isco88, values)
es06f <- es06 %>% group_by(isco88) %>% summarize(es06 = sum(values))

es10 <- filter(ses1053, sex == "T", geo == "EU28") %>%
  select(sizeclas, isco08, values)
es10f <- es10 %>% group_by(isco08) %>% summarize(es10 = sum(values))

es14 <- filter(ses1453, sex == "T", geo == "EU28") %>%
  select(sizeclas, isco08, values)
es14f <- es14 %>% group_by(isco08) %>% summarize(es14 = sum(values))

occlist02 <- c("OC0", "OC1", "OC1-5", "OC2", "OC3", "OC4", "OC5", "OC7", "OC7-9",
               "OC8", "OC9", "TOTAL", "UNK")
occlist06 <- c("OC0", "OC1", "OC1-5", "OC2", "OC3", "OC4", "OC5", "OC6", "OC7", "OC7-9",
               "OC8", "OC9", "TOTAL", "UNK")
es02$isco88 <- occlist02
es06f$isco88 <- occlist06

colnames(es02) <- c("occupation", "es02")
colnames(es06f) <- c("occupation", "es06")
colnames(es10f) <- c("occupation", "es10")
colnames(es14f) <- c("occupation", "es14")

table4 <- Reduce(function(x, y) merge(x, y, by = "occupation", all=TRUE),
                 list(es02, es06f, es10f, es14f))

calibrationTargets_Employment <- table4[-c(1, 3, 10, 14), ]
write.csv(calibrationTargets_Employment, file = "./tables/calibrationTargets_Employment.csv", row.names = F)
