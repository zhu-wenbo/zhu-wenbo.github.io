## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu  (email: wenbo.zhu@uibe.edu.cn)                           ##
##     last modified:  JUNE 2021                                              ##
## -------------------------------------------------------------------------- ##

There are SIX main R code files for this project:

  1. fig1.R
    - plots Figure 1 in the paper
    - the downloaded raw data file is put here './figs/gdppwe.csv'
    - output: './figs/Figure1_data.csv', and './figs/fig1.eps'
        - the file './figs/Figure1_data.csv' also contains calibration targets for trend growth of GDP
        

  2. fig2.R 
    - retrieves and cleans the data for Figure 2 in the paper
    - the downloaded raw data files from Eurostat are put in the directory of './eurostat_RAWdata/'
        - I kept a copy of the raw data files that I used in the directory
    - the cleaned data files are put in the directory of './eurostat_CLEANEDdata/' 
    - output: './tables/rtpcsw.csv', which is included as Table 4 in the Data Appendix in the paper
    - the actual Figure 2 is plotted by the 'Numbers.app' on macOS and exported as './tables/fig2.pdf'
    	- the file is './tables/rtpc.numbers'


  3. calibrationTargets.R
    - retrieves and cleans the data for calculating some of the calibration targets
    - the downloaded raw data files from Eurostat are put in the directory of './eurostat_RAWdata/'
       - I kept a copy of the raw data files that I used in the directory
    - output: './tables/calibrationTargets_Wages.csv', and './tables/calibrationTargets_Employment.csv'
       - then the information is consolidated using the 'Numbers.app'
       - the file is './tables/calibrationTargets.numbers'


  4. calibration.R
    - "prob.R" should be run before this file
    - calibrates the model to 2000 and 2014 (Table 2 in the paper)
    - conducts the decomposition exercise (Table 3 in the paper)


  5. transition_lhm.R (expected computation time: 1.7 hours)
    - "prob.R" should be run before this file
    - conducts the first quantitative exercise in which I gradually and permanently reduce the rate of process innovation lambda_HM
    - plots Figure 4 and exports them in the directory of './figs/'
    	- it also saves an intermediate result "./outputs/Ptrans_lhm.rds", which stores the transitional matrices for this exercise.


  6. transition_lml.R (expected computation time: 27 mins)
    - "prob.R" should be run before this file
    - conducts the second quantitative exercise in which I gradually and permanently reduce the rate of process innovation lambda_ML
    - plots Figure 5 and exports them in the directory of './figs/'
    	- it also saves an intermediate result "./outputs/Ptrans_lml.rds", which stores the transitional matrices for this exercise.

There are also two auxiliary R code files:

  1. model.R
    - keeps all the function definitions
    - this file is sourced in 'calibration.R', 'transition_lhm.R', and 'transition_lml.R'

  2. probs.R (run time: 14 secs)
    - calculates the transition matrices
    - output: './outputs/P2000.txt', './outputs/P2014.txt', './outputs/P_lhm.txt', './outputs/P_lml.txt'
    - the outputs are used in 'calibration.R', 'transition_lhm.R', and 'transition_lml.R'
	- so this file needs to run *before* the above three files

* Please note that I have commented out the data retrieving part of the code.  Instead, I have included the raw data that I used to get the results in the paper.  All code files are adjusted accordingly so they are all ready to run.  I do this for reproducibility reasons, as I have noticed that Eurostat update their data (i.e., data values, data structure, variable names, and etc) occasionally.

================================================================
The above code files are tested in the following environment:
    1. macOS Mojave Version 10.14.6 
    2. R version 4.0.3 (2020-10-10) -- "Bunny-Wunnies Freak Out"
        Platform: x86_64-apple-darwin18.7.0 (64-bit)

    MacBook Pro (13-inch, 2017, Two Thunderbolt 3 ports)
    Processor 2.3 GHz Intel Core i5
    Memory 8GB 2133 MHz LPDDR3