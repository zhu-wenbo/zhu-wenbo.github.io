## -------------------------------------------------------------------------- ##
## "Hollowing out and slowing growth: the role of process innovations"        ##
##     by Wenbo Zhu                                                           ##
##     last modified:  June 2021                                              ##
## -------------------------------------------------------------------------- ##

## this file retrieves the relevant data and then plot Figure 1 in the paper.

getwd()

library(WDI)     # load worldbank indicator data
library(mFilter) # HP filter


## ## retrieves the data from WDI and save it
## gdppweData <-  WDI(indicator= "SL.GDP.PCAP.EM.KD", country="EU", end=2020) # "GDP per worker employed (constant 2011 PPP $)"
## write.csv(x = gdppweData, file = "./figs/gdppwe.csv") # export the data file

## load the downloaded WDI data
gdppweData <- read.csv(file = "./figs/gdppwe.csv")


## calucualtes GDP (per worker employed) growth rate %
gdppwe <- data.frame(rev(gdppweData$year), rev(gdppweData$SL.GDP.PCAP.EM.KD))
colnames(gdppwe) <- c("year", "GDP_per_worker_growth")
gdppwec <- gdppwe[complete.cases(gdppwe), ]
# --------------------------------------------------------------------------- #
# a function for getting the growth rates of a vector
GR <- function(x){
    ll <- length(x) # get the length
    temp <- rep(NA, ll) # create an empty vector
    for(i in 2:ll){
        temp[i] <- (x[i] - x[i-1])/x[i-1]*100
    }
    temp
}
# --------------------------------------------------------------------------- #
gdppwec$growth <- GR(gdppwec$GDP_per_worker_growth)
dat <- gdppwec[-1,] # remove the first row with NA


## calculate the HP trend
dat$hptrend <- hpfilter(dat$growth, freq = 6.25, type = "lambda")$trend

write.csv(x = dat, file = "./figs/Figure1_data.csv") # export the data for
                                                     # plotting Figure 1, this
                                                     # is useful for getting
                                                     # trend growth as one
                                                     # calibration targets

## plots Figure 1 in EPS format
setEPS()
postscript(file = "./figs/fig1.eps")
plot(x = dat$year, y = dat$growth, type = "b", pch = 20, col = "blue",
     lwd = 2,
     xlab = "Year",
     ylab = "Percentage Point",
     main = "GDP per employed worker growth rate in the \nEuropean Union (1991 - 2019)"
)
abline(h = 0, lty = 2)
lines(x = dat$year, y = dat$hptrend, col = "red", lwd = 2)
legend("bottomleft",
       legend = c("GDP per employed worker", "HP-trend"),
       col = c("blue", "red"),
       lwd = c(2, 2),
       pch = c(20, NA)
       )
dev.off()
